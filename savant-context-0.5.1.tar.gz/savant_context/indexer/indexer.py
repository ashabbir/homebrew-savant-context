"""Main repository indexer coordinator."""

import logging
import os
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any

from pygments.lexers import get_lexer_for_filename, guess_lexer
from pygments.util import ClassNotFound

from ..db.client import DatabaseClient
from .chunker import ContentChunker
from .walker import FileWalker

logger = logging.getLogger(__name__)


class Indexer:
    """Repository indexer that walks files, chunks content, and stores in database."""

    def __init__(self, db_client: DatabaseClient):
        """Initialize indexer.

        Args:
            db_client: DatabaseClient instance
        """
        self.db = db_client
        self.chunker = ContentChunker()

    def detect_language(self, file_path: Path) -> Optional[str]:
        """Detect programming language for a file.

        Args:
            file_path: Path to file

        Returns:
            Language name or None
        """
        try:
            lexer = get_lexer_for_filename(file_path.name)
            return lexer.name
        except ClassNotFound:
            try:
                # Try to guess from content
                if file_path.stat().st_size < 10_000_000:  # Max 10MB
                    with open(file_path, "r", encoding="utf-8", errors="ignore") as f:
                        content = f.read(1000)
                    lexer = guess_lexer(content)
                    return lexer.name
            except Exception:
                pass

        return None

    def generate_fts_vector(self, text: str) -> str:
        """Generate PostgreSQL FTS tsvector.

        Args:
            text: Text to index

        Returns:
            tsvector SQL expression
        """
        # Escape single quotes for SQL
        escaped_text = text.replace("'", "''")
        return f"to_tsvector('english', '{escaped_text}')"

    def index_repository(
        self, repo_path: Path, repo_name: Optional[str] = None, verbose: bool = True
    ) -> Dict[str, Any]:
        """Index a repository.

        Args:
            repo_path: Path to repository
            repo_name: Optional repository name (default: folder name)
            verbose: Whether to log progress

        Returns:
            Dictionary with indexing statistics
        """
        repo_path = Path(repo_path).resolve()

        if not repo_path.exists():
            raise FileNotFoundError(f"Repository path does not exist: {repo_path}")

        if not repo_path.is_dir():
            raise NotADirectoryError(f"Repository path is not a directory: {repo_path}")

        repo_name = repo_name or repo_path.name

        if verbose:
            logger.info(f"Starting index of repository: {repo_name} at {repo_path}")

        try:
            # Check if repo already exists
            existing = self.db.fetch_one(
                "SELECT id, indexed_at FROM repos WHERE name = %s", (repo_name,)
            )

            if existing:
                repo_id = existing["id"]
                logger.info(f"Repository '{repo_name}' already indexed, updating...")
                # Delete old chunks and files for this repo
                self.db.execute("DELETE FROM chunks WHERE file_id IN (SELECT id FROM files WHERE repo_id = %s)", (repo_id,))
                self.db.execute("DELETE FROM files WHERE repo_id = %s", (repo_id,))
            else:
                # Insert new repo
                result = self.db.fetch_one(
                    "INSERT INTO repos (name, path, indexed_at) VALUES (%s, %s, %s) RETURNING id",
                    (repo_name, str(repo_path), datetime.now()),
                )
                repo_id = result["id"]

            # Walk files
            walker = FileWalker(repo_path)
            files_to_index = list(walker.walk())
            total_files = len(files_to_index)

            if verbose:
                logger.info(f"Found {total_files} files to index")

            files_indexed = 0
            chunks_indexed = 0
            errors = 0

            # Process each file
            for file_rel_path in files_to_index:
                try:
                    file_abs_path = repo_path / file_rel_path

                    # Get file stats
                    stat = file_abs_path.stat()
                    mtime_ns = int(stat.st_mtime_ns)

                    # Skip very large files
                    if stat.st_size > 50_000_000:  # 50MB
                        logger.debug(f"Skipping large file: {file_rel_path}")
                        continue

                    # Read file content
                    try:
                        with open(file_abs_path, "r", encoding="utf-8", errors="ignore") as f:
                            content = f.read()
                    except Exception as e:
                        logger.warning(f"Failed to read {file_rel_path}: {e}")
                        errors += 1
                        continue

                    # Detect language
                    language = self.detect_language(file_rel_path)

                    # Insert file record
                    file_result = self.db.fetch_one(
                        "INSERT INTO files (repo_id, rel_path, language, mtime_ns, indexed_at) "
                        "VALUES (%s, %s, %s, %s, %s) RETURNING id",
                        (repo_id, str(file_rel_path), language, mtime_ns, datetime.now()),
                    )
                    file_id = file_result["id"]
                    files_indexed += 1

                    # Chunk and index content
                    chunks = self.chunker.chunk_with_metadata(content)

                    for chunk_index, chunk_text in chunks:
                        # Generate FTS vector inline in SQL
                        self.db.execute(
                            "INSERT INTO chunks (file_id, chunk_index, content, content_vector) "
                            "VALUES (%s, %s, %s, to_tsvector('english', %s))",
                            (file_id, chunk_index, chunk_text, chunk_text),
                        )
                        chunks_indexed += 1

                    if verbose and files_indexed % 10 == 0:
                        logger.info(f"Indexed {files_indexed}/{total_files} files...")

                except Exception as e:
                    logger.error(f"Error indexing {file_rel_path}: {e}")
                    errors += 1
                    continue

            # Update repo indexed_at timestamp
            self.db.execute(
                "UPDATE repos SET indexed_at = %s WHERE id = %s",
                (datetime.now(), repo_id),
            )

            result = {
                "repo_name": repo_name,
                "repo_path": str(repo_path),
                "files_indexed": files_indexed,
                "chunks_indexed": chunks_indexed,
                "errors": errors,
                "timestamp": datetime.now().isoformat(),
            }

            if verbose:
                logger.info(
                    f"Indexing complete: {files_indexed} files, {chunks_indexed} chunks, {errors} errors"
                )

            return result

        except Exception as e:
            logger.error(f"Failed to index repository: {e}")
            raise

    def delete_repository(self, repo_name: str) -> Dict[str, Any]:
        """Delete a repository from index.

        Args:
            repo_name: Name of repository to delete

        Returns:
            Dictionary with deletion stats
        """
        logger.info(f"Deleting repository: {repo_name}")

        try:
            repo = self.db.fetch_one("SELECT id FROM repos WHERE name = %s", (repo_name,))

            if not repo:
                raise ValueError(f"Repository not found: {repo_name}")

            repo_id = repo["id"]

            # Delete cascades to files and chunks
            self.db.execute("DELETE FROM repos WHERE id = %s", (repo_id,))

            logger.info(f"Repository deleted: {repo_name}")

            return {"repo_name": repo_name, "deleted": True}

        except Exception as e:
            logger.error(f"Failed to delete repository: {e}")
            raise

    def get_repository_stats(self) -> list:
        """Get statistics for all indexed repositories.

        Returns:
            List of repository stats
        """
        query = """
            SELECT
                r.id,
                r.name,
                r.path,
                r.indexed_at,
                COUNT(DISTINCT f.id) as file_count,
                COUNT(DISTINCT c.id) as chunk_count,
                MAX(f.mtime_ns) as latest_mtime_ns
            FROM repos r
            LEFT JOIN files f ON r.id = f.repo_id
            LEFT JOIN chunks c ON f.id = c.file_id
            GROUP BY r.id, r.name, r.path, r.indexed_at
            ORDER BY r.name
        """

        return self.db.fetch_all(query)
