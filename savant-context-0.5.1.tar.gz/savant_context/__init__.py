"""Savant Context MCP - Code indexer and context provider."""

__version__ = "0.5.0"
__author__ = "Ashabbir"
__email__ = "ashabbir@github.com"

__all__ = ["__version__"]
