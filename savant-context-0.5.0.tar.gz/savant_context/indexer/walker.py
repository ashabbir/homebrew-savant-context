"""File system walker with .gitignore support."""

import logging
from pathlib import Path
from typing import Iterator, Optional, Set

import pathspec

logger = logging.getLogger(__name__)


class FileWalker:
    """Walk through files respecting .gitignore patterns."""

    # Common patterns to skip
    DEFAULT_SKIP_PATTERNS = {
        "node_modules",
        ".git",
        ".venv",
        "venv",
        "__pycache__",
        ".pytest_cache",
        ".tox",
        "dist",
        "build",
        "*.egg-info",
        ".mypy_cache",
    }

    # File extensions to skip (binary files)
    SKIP_EXTENSIONS = {
        ".pyc",
        ".pyo",
        ".so",
        ".o",
        ".a",
        ".exe",
        ".dll",
        ".dylib",
        ".jpg",
        ".jpeg",
        ".png",
        ".gif",
        ".pdf",
        ".zip",
        ".tar",
        ".gz",
        ".bin",
        ".class",
        ".jar",
    }

    def __init__(self, repo_path: Path):
        """Initialize file walker.

        Args:
            repo_path: Root path of repository to walk
        """
        self.repo_path = Path(repo_path).resolve()
        self.gitignore_spec: Optional[pathspec.PathSpec] = None
        self._load_gitignore()

    def _load_gitignore(self) -> None:
        """Load .gitignore patterns if present."""
        gitignore_path = self.repo_path / ".gitignore"

        if gitignore_path.exists():
            try:
                with open(gitignore_path, "r", encoding="utf-8", errors="ignore") as f:
                    patterns = f.read().splitlines()
                self.gitignore_spec = pathspec.PathSpec.from_lines("gitwildmatch", patterns)
                logger.debug(f"Loaded .gitignore from {gitignore_path}")
            except Exception as e:
                logger.warning(f"Failed to load .gitignore: {e}")

    def _should_skip(self, path: Path) -> bool:
        """Check if path should be skipped.

        Args:
            path: Path to check

        Returns:
            True if path should be skipped
        """
        # Check file extension
        if path.suffix.lower() in self.SKIP_EXTENSIONS:
            return True

        # Check name against default patterns
        for pattern in self.DEFAULT_SKIP_PATTERNS:
            if pattern.replace("*.", "").replace("*", "") in path.parts:
                return True

        # Check against .gitignore
        if self.gitignore_spec:
            try:
                rel_path = path.relative_to(self.repo_path)
                # gitignore matching is case-sensitive on Unix, case-insensitive on Windows
                if self.gitignore_spec.match_file(str(rel_path)):
                    return True
            except (ValueError, Exception):
                pass

        return False

    def walk(self) -> Iterator[Path]:
        """Yield all non-skipped files in the repository.

        Yields:
            Path: File paths relative to repo root
        """
        try:
            for item in self.repo_path.rglob("*"):
                if item.is_file():
                    if not self._should_skip(item):
                        yield item.relative_to(self.repo_path)
                    else:
                        logger.debug(f"Skipping: {item.relative_to(self.repo_path)}")
        except Exception as e:
            logger.error(f"Error walking repository: {e}")

    def get_file_count(self) -> int:
        """Get total count of files to index.

        Returns:
            Number of files
        """
        return sum(1 for _ in self.walk())
