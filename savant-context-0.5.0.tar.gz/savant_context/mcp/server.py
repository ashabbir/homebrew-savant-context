"""MCP (Model Context Protocol) server implementation."""

import json
import logging
import sys
from typing import Any, Dict

from ..db.client import DatabaseClient
from .tools import ToolHandler, get_tool_definitions

logger = logging.getLogger(__name__)


class MCPServer:
    """MCP server for code context and search."""

    def __init__(self, db_client: DatabaseClient):
        """Initialize MCP server.

        Args:
            db_client: DatabaseClient instance
        """
        self.db = db_client
        self.tool_handler = ToolHandler(db_client)

    def run(self) -> None:
        """Run MCP server with stdio transport."""
        logger.info("Starting MCP server with stdio transport...")
        logger.info("MCP server ready. Waiting for tool calls on stdin...")
        logger.info(f"Available tools: {[t['name'] for t in get_tool_definitions()]}")

        try:
            while True:
                try:
                    line = input()
                    if not line.strip():
                        continue

                    request = json.loads(line)
                    tool_name = request.get("tool")
                    args = request.get("args", {})

                    logger.info(f"Tool called: {tool_name} with args: {args}")

                    if tool_name == "search":
                        result = self.tool_handler.search_sync(
                            query=args.get("query"),
                            repo=args.get("repo"),
                            limit=args.get("limit", 10),
                        )
                    elif tool_name == "list_repos":
                        result = self.tool_handler.list_repos_sync()
                    elif tool_name == "repo_stats":
                        result = self.tool_handler.repo_stats_sync(
                            repo_name=args.get("repo_name")
                        )
                    elif tool_name == "index_repo":
                        result = self.tool_handler.index_repo_sync(
                            path=args.get("path"), name=args.get("name")
                        )
                    elif tool_name == "delete_repo":
                        result = self.tool_handler.delete_repo_sync(name=args.get("name"))
                    else:
                        result = {"error": f"Unknown tool: {tool_name}"}

                    response = {"status": "success", "result": result}
                    print(json.dumps(response))
                    sys.stdout.flush()

                except json.JSONDecodeError as e:
                    error_response = {"status": "error", "message": f"Invalid JSON: {e}"}
                    print(json.dumps(error_response))
                    sys.stdout.flush()
                except Exception as e:
                    logger.error(f"Tool execution failed: {e}")
                    error_response = {"status": "error", "message": str(e)}
                    print(json.dumps(error_response))
                    sys.stdout.flush()

        except KeyboardInterrupt:
            logger.info("MCP server shutting down...")
        except EOFError:
            logger.info("MCP server connection closed...")
