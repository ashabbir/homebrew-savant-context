"""Savant Context MCP - Code indexer and context provider."""

__version__ = "0.1.0"
__author__ = "Your Name"
__email__ = "your.email@example.com"

__all__ = ["__version__"]
