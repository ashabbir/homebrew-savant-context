# Savant Context - Code Indexer & MCP Server

A standalone MCP (Model Context Protocol) server with PostgreSQL-based code indexer. Index your repositories and search across all your code through an MCP interface or CLI.

## Features

- **Full-Text Search** - Search across indexed repositories with PostgreSQL FTS
- **Code Indexing** - Automatically detect language, chunk content, and index efficiently
- **MCP Compatible** - Works with Claude Desktop and any MCP client
- **Database Management** - Dump and restore indexed data
- **CLI Interface** - Simple commands for all operations
- **No Configuration** - Environment variables only, no config files

## Installation

### Homebrew

```bash
brew tap ashabbir/savant-context https://github.com/ashabbir/context
brew install savant-context
```

Or directly from the formula:
```bash
brew install ashabbir/savant-context/savant-context
```

### From Source

```bash
git clone https://github.com/ashabbir/context.git
cd context
pip install -e .
```

### Requirements

- Python 3.10+
- PostgreSQL 12+

## Quick Start

### 1. Setup the Database

```bash
savant-context db setup
```

This creates the PostgreSQL database and schema.

### 2. Index a Repository

```bash
savant-context index repo ./path/to/repo
```

Or specify a custom name:

```bash
savant-context index repo ./path/to/repo --name my-project
```

### 3. Check Status

```bash
savant-context status
```

Shows all indexed repositories with file and chunk counts.

### 4. Start the MCP Server

```bash
savant-context run
```

The server runs on stdio transport, ready for MCP clients.

## CLI Commands

### Database Management

```bash
# Initialize database and schema
savant-context db setup

# Dump database to file
savant-context db dump ./backup.dump

# Restore database from file
savant-context db restore ./backup.dump
```

### Repository Management

```bash
# Index a repository
savant-context index repo ./path/to/repo

# Index with custom name
savant-context index repo ./path/to/repo --name custom-name

# Show all indexed repositories
savant-context status
```

### Server

```bash
# Start MCP server
savant-context run

# Runs on stdio transport for MCP clients
```

## MCP Tools

Once running, the following tools are available:

### `search`

Full-text search across indexed code.

```json
{
  "query": "function def",
  "repo": "optional-repo-name",
  "limit": 10
}
```

### `list_repos`

List all indexed repositories.

### `repo_stats`

Get statistics for repositories.

```json
{
  "repo_name": "optional-specific-repo"
}
```

### `index_repo`

Trigger repository indexing from MCP.

```json
{
  "path": "/path/to/repo",
  "name": "optional-name"
}
```

### `delete_repo`

Remove a repository from the index.

```json
{
  "name": "repo-name"
}
```

## Configuration

Configuration uses environment variables (no config files):

```bash
# PostgreSQL connection
export POSTGRES_HOST=localhost                   # default: localhost
export POSTGRES_PORT=5432                       # default: 5432
export POSTGRES_DB=savant-context-standalone   # default: savant-context-standalone
export POSTGRES_USER=$USER                      # default: current user
export POSTGRES_PASSWORD=                       # optional

# Logging
export LOG_LEVEL=info                           # default: info
```

## Database Schema

### repos
- `id` (SERIAL PRIMARY KEY)
- `name` (TEXT UNIQUE) - Repository name
- `path` (TEXT) - Repository path
- `indexed_at` (TIMESTAMP) - Last indexing time
- `created_at` (TIMESTAMP) - Creation time

### files
- `id` (SERIAL PRIMARY KEY)
- `repo_id` (INTEGER FK) - Repository ID
- `rel_path` (TEXT) - Relative file path
- `language` (TEXT) - Detected language
- `mtime_ns` (BIGINT) - File modification time
- `indexed_at` (TIMESTAMP) - Indexing time
- `created_at` (TIMESTAMP) - Creation time

### chunks
- `id` (SERIAL PRIMARY KEY)
- `file_id` (INTEGER FK) - File ID
- `chunk_index` (INTEGER) - Chunk sequence number
- `content` (TEXT) - Chunk content
- `content_vector` (tsvector) - PostgreSQL FTS vector
- `created_at` (TIMESTAMP) - Creation time

## Usage Examples

### Index Multiple Repositories

```bash
savant-context index:repo ~/projects/project-a --name project-a
savant-context index:repo ~/projects/project-b --name project-b
savant-context index:repo ~/projects/project-c --name project-c
```

### Backup and Restore

```bash
# Backup current index
savant-context db:dump ~/backups/index-$(date +%Y%m%d).dump

# Restore from backup
savant-context db:restore ~/backups/index-20250115.dump
```

### Use with Claude Desktop

Configure in `claude_desktop_config.json`:

```json
{
  "mcpServers": {
    "savant-context": {
      "command": "savant-context",
      "args": ["run"]
    }
  }
}
```

Then restart Claude Desktop to connect to the MCP server.

## Development

### Install for Development

```bash
git clone https://github.com/ashabbir/context.git
cd context
pip install -e ".[dev]"
```

### Run Tests

```bash
pytest
```

### Code Quality

```bash
# Format code
black savant_context

# Lint code
pylint savant_context

# Type checking
mypy savant_context
```

## Troubleshooting

### Database Connection Error

```
Error: Failed to connect to database
```

Ensure PostgreSQL is running:

```bash
# macOS
brew services start postgresql@14

# Linux
sudo systemctl start postgresql
```

### pg_dump Not Found

```
pg_dump command not found
```

Install PostgreSQL client tools:

```bash
# macOS
brew install postgresql@14

# Ubuntu
sudo apt-get install postgresql-client

# Fedora
sudo dnf install postgresql
```

### Import Errors

```
ModuleNotFoundError: No module named 'mcp'
```

Reinstall the package:

```bash
pip install -e .
```

## Performance Tips

1. **Large Repositories** - Very large files (>50MB) are skipped automatically
2. **Incremental Indexing** - Re-indexing only processes changed files
3. **Chunk Size** - Adjust chunking in `savant_context/indexer/chunker.py` if needed
4. **FTS Optimization** - PostgreSQL indexes are created automatically

## Architecture

```
savant-context/
├── cli.py              # CLI commands
├── config.py           # Configuration
├── db/
│   ├── client.py       # PostgreSQL client
│   ├── schema.py       # Schema definitions
│   └── operations.py   # Dump/restore
├── indexer/
│   ├── walker.py       # File system walker
│   ├── chunker.py      # Content chunking
│   └── indexer.py      # Indexing coordinator
└── mcp/
    ├── server.py       # MCP server
    └── tools.py        # Tool implementations
```

## License

MIT License - See LICENSE file for details

## Contributing

Contributions welcome! Please:

1. Fork the repository
2. Create a feature branch
3. Make your changes
4. Write tests
5. Submit a pull request

## Support

- Report issues on [GitHub](https://github.com/ashabbir/context/issues)
- Check documentation in this README
- Review code examples above

## Roadmap

- [ ] Web UI for repository management
- [ ] Vector embeddings for semantic search
- [ ] Incremental indexing optimization
- [ ] Multi-language support improvements
- [ ] Export capabilities (JSON, CSV)
