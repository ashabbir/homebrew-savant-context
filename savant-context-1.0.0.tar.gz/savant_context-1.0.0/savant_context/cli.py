"""CLI for savant-context."""

import logging
from pathlib import Path
from typing import Optional

import click

from . import __version__
from .config import Config
from .db import DatabaseClient, init_schema
from .db.operations import dump_database, restore_database, create_database
from .indexer import Indexer
from .mcp.server import MCPServer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# ASCII Art
BANNER = """
 ███████╗ █████╗ ██╗   ██╗ █████╗ ██╗   ██╗████████╗
 ██╔════╝██╔══██╗██║   ██║██╔══██╗██║   ██║╚══██╔══╝
 ███████╗███████║██║   ██║███████║██║   ██║   ██║
 ╚════██║██╔══██║╚██╗ ██╔╝██╔══██║██║   ██║   ██║
 ███████║██║  ██║ ╚████╔╝ ██║  ██║╚██████╔╝   ██║
 ╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝    ╚═╝

 Context - MCP Server with Code Indexer
 By AmdSh
 Version: {version}
"""


def get_db_client() -> DatabaseClient:
    """Get a connected database client."""
    client = DatabaseClient()
    try:
        client.connect()
    except Exception as e:
        click.echo(f"Error: Failed to connect to database: {e}", err=True)
        raise click.Abort()
    return client


def print_banner() -> None:
    """Print the ASCII art banner."""
    click.echo(BANNER.format(version=__version__))


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="savant-context")
@click.pass_context
def main(ctx) -> None:
    """Savant Context - Code indexer and MCP server."""
    # Always print banner for any command
    print_banner()

    if ctx.invoked_subcommand is None:
        pass  # Banner already printed


@main.command()
def run() -> None:
    """Start the MCP server."""
    click.echo("Starting Savant Context MCP server...")

    db_client = get_db_client()

    try:
        # Verify schema exists
        if not db_client.table_exists("repos"):
            click.echo("Database schema not initialized. Run 'db:setup' first.", err=True)
            db_client.close()
            raise click.Abort()

        # Create and run MCP server
        mcp = MCPServer(db_client)
        click.echo("MCP server running. Press Ctrl+C to stop.")

        try:
            mcp.run()
        except KeyboardInterrupt:
            click.echo("\nShutting down...")
        finally:
            db_client.close()

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@main.group()
def db() -> None:
    """Database management commands."""
    pass


@db.command(name="setup")
def db_setup() -> None:
    """Initialize the database and create schema."""
    click.echo("Setting up database...")

    try:
        # Create database if it doesn't exist
        click.echo("Creating database if needed...")
        create_database()
        click.echo("✓ Database ready")

        # Connect and initialize schema
        db_client = get_db_client()
        init_schema(db_client)
        click.echo("✓ Database schema initialized successfully")
        db_client.close()

    except Exception as e:
        click.echo(f"Error: Failed to initialize database: {e}", err=True)
        raise click.Abort()


@db.command(name="dump")
@click.argument("output_path", type=click.Path())
def db_dump(output_path: str) -> None:
    """Dump the database to a file.

    OUTPUT_PATH: Path where to save the dump file
    """
    output_file = Path(output_path)

    if output_file.exists():
        if not click.confirm(f"File {output_path} exists. Overwrite?"):
            click.echo("Aborted")
            return

    click.echo(f"Dumping database to {output_path}...")

    try:
        dump_database(output_file)
        click.echo(f"✓ Database dumped successfully to {output_path}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="restore")
@click.argument("dump_path", type=click.Path(exists=True))
@click.option("--clean", is_flag=True, help="Drop objects before restoring")
def db_restore(dump_path: str, clean: bool) -> None:
    """Restore the database from a dump file.

    DUMP_PATH: Path to the dump file
    """
    if not click.confirm(f"Restore database from {dump_path}? This will replace existing data."):
        click.echo("Aborted")
        return

    click.echo(f"Restoring database from {dump_path}...")

    try:
        # Create database if it doesn't exist
        click.echo("Creating database if needed...")
        create_database()
        click.echo("✓ Database ready")

        # Restore from dump
        restore_database(Path(dump_path), clean=clean)
        click.echo(f"✓ Database restored successfully from {dump_path}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="destroy")
def db_destroy() -> None:
    """Destroy the database completely.

    WARNING: This permanently deletes all indexed data.
    """
    if not click.confirm("⚠️  This will permanently delete ALL indexed data. Are you sure?"):
        click.echo("Aborted")
        return

    if not click.confirm("Type 'destroy' to confirm permanent deletion"):
        click.echo("Aborted")
        return

    click.echo("Destroying database...")

    try:
        db_client = get_db_client()

        # Drop all tables
        db_client.execute("DROP TABLE IF EXISTS chunks CASCADE")
        db_client.execute("DROP TABLE IF EXISTS files CASCADE")
        db_client.execute("DROP TABLE IF EXISTS repos CASCADE")

        click.echo("✓ Database destroyed successfully")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@main.command()
def status() -> None:
    """Show detailed status of indexed repositories."""
    db_client = get_db_client()

    try:
        # Check if schema exists
        if not db_client.table_exists("repos"):
            click.echo("No repositories indexed yet. Run 'index repo' to start indexing.")
            return

        # Get repository stats with language breakdown
        repos = db_client.fetch_all(
            """
            SELECT
                r.id,
                r.name,
                r.indexed_at,
                COUNT(DISTINCT f.id) as file_count,
                COUNT(DISTINCT c.id) as chunk_count
            FROM repos r
            LEFT JOIN files f ON r.id = f.repo_id
            LEFT JOIN chunks c ON f.id = c.file_id
            GROUP BY r.id, r.name, r.indexed_at
            ORDER BY r.name
            """
        )

        if not repos:
            click.echo("No repositories indexed yet. Run 'index repo' to start indexing.")
            return

        # Display repository header
        click.echo("\n" + "=" * 100)
        click.echo("📊 REPOSITORY STATUS")
        click.echo("=" * 100)

        total_files_indexed = 0
        total_files_notindexed = 0
        total_chunks = 0
        all_languages = {}

        for repo in repos:
            repo_id = repo["id"]
            repo_name = repo["name"]
            file_count = repo["file_count"] or 0
            chunk_count = repo["chunk_count"] or 0
            indexed_at = repo["indexed_at"] or "Never"

            total_files_indexed += file_count
            total_chunks += chunk_count

            # Get language breakdown for this repo
            lang_stats = db_client.fetch_all(
                """
                SELECT language, COUNT(*) as count
                FROM files
                WHERE repo_id = %s
                GROUP BY language
                ORDER BY count DESC
                """,
                (repo_id,)
            )

            click.echo(f"\n📁 {repo_name}")
            click.echo("─" * 100)
            click.echo(f"  Last Indexed: {indexed_at}")
            click.echo(f"  Files (Memory Bank): {file_count:,}")
            click.echo(f"  Chunks (FTS Index): {chunk_count:,}")

            # Show file breakdown by type
            if lang_stats:
                click.echo(f"  Files by Type:")
                for lang_stat in lang_stats:
                    lang = lang_stat["language"] or "unknown"
                    count = lang_stat["count"]
                    percentage = (count / file_count * 100) if file_count > 0 else 0
                    all_languages[lang] = all_languages.get(lang, 0) + count
                    click.echo(f"    • {lang:<15} {count:>6,} files ({percentage:>5.1f}%)")

        # Display totals
        click.echo("\n" + "=" * 100)
        click.echo("📈 SUMMARY")
        click.echo("=" * 100)
        click.echo(f"Total Repositories: {len(repos)}")
        click.echo(f"Total Files (Memory Bank): {total_files_indexed:,}")
        click.echo(f"Total Chunks (FTS Index): {total_chunks:,}")

        # Overall language breakdown
        click.echo(f"\nFiles by Type (Overall):")
        sorted_langs = sorted(all_languages.items(), key=lambda x: x[1], reverse=True)
        for lang, count in sorted_langs:
            percentage = (count / total_files_indexed * 100) if total_files_indexed > 0 else 0
            click.echo(f"  • {lang:<15} {count:>6,} files ({percentage:>5.1f}%)")

        click.echo("=" * 100 + "\n")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@main.group()
def index() -> None:
    """Repository indexing commands."""
    pass


@index.command(name="repo")
@click.argument("path", type=click.Path(exists=True, file_okay=False, dir_okay=True), required=False, default=".")
@click.option("--name", default=None, help="Repository name (default: folder name)")
def index_repo(path: str, name: Optional[str]) -> None:
    """Index a repository.

    PATH: Path to the repository to index (default: current directory)
    """
    repo_path = Path(path).resolve()
    repo_name = name or repo_path.name

    click.echo(f"Indexing repository: {repo_name}")
    click.echo(f"Path: {repo_path}")

    db_client = get_db_client()

    try:
        # Check if schema exists
        if not db_client.table_exists("repos"):
            click.echo("Database schema not initialized. Run 'db:setup' first.", err=True)
            raise click.Abort()

        indexer = Indexer(db_client)
        result = indexer.index_repository(repo_path, repo_name=repo_name, verbose=True)

        click.echo("\n✓ Indexing complete")
        click.echo(f"  Files indexed: {result['files_indexed']}")
        click.echo(f"  Chunks indexed: {result['chunks_indexed']}")
        if result["errors"]:
            click.echo(f"  Errors: {result['errors']}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@main.command()
def readme() -> None:
    """Display the full README documentation."""
    readme_path = Path(__file__).parent.parent / "README.md"

    if not readme_path.exists():
        click.echo("Error: README.md not found", err=True)
        raise click.Abort()

    try:
        with open(readme_path, "r", encoding="utf-8") as f:
            content = f.read()
        click.echo(content)
    except Exception as e:
        click.echo(f"Error reading README: {e}", err=True)
        raise click.Abort()


def savant_shortcut() -> None:
    """Shortcut command that automatically runs the MCP server."""
    import sys
    # Insert 'run' as the first argument after 'savant'
    sys.argv.insert(1, 'run')
    main()


if __name__ == "__main__":
    main()
