# Getting Started with Savant Context

## Prerequisites

1. **Python 3.11+** installed
2. **PostgreSQL 12+** installed and running

### Install PostgreSQL (macOS)

```bash
brew install postgresql@14
brew services start postgresql@14
```

### Install PostgreSQL (Linux - Ubuntu)

```bash
sudo apt update
sudo apt install postgresql postgresql-contrib
sudo systemctl start postgresql
```

## Installation

### Option 1: Development Installation

```bash
cd /Users/home/code/context
pip install -e .
```

### Option 2: Regular Installation

```bash
cd /Users/home/code/context
pip install .
```

### Verify Installation

```bash
savant-context --version
```

You should see: `savant-context, version 0.1.0`

## Step-by-Step Usage

### Step 1: Initialize the Database

```bash
savant-context db:setup
```

Expected output:
```
Setting up database...
✓ Database schema initialized successfully
```

This creates:
- PostgreSQL database: `savant_context`
- Tables: repos, files, chunks
- Indexes for performance

### Step 2: Index Your First Repository

```bash
savant-context index:repo /Users/home/code/savant-mvp --name savant-mvp
```

Expected output:
```
Indexing repository: savant-mvp
Path: /Users/home/code/savant-mvp
Found 1234 files to index
...
✓ Indexing complete
  Files indexed: 1234
  Chunks indexed: 5678
  Errors: 0
```

### Step 3: Check Status

```bash
savant-context status
```

Expected output:
```
Repository Status
──────────────────────────────────────────────────────────
Name              Files    Chunks    Last Indexed
──────────────────────────────────────────────────────────
savant-mvp        1,234    5,678     2025-01-15 10:30:45
──────────────────────────────────────────────────────────
Total:            1,234    5,678     1 repositories
```

### Step 4: Start the MCP Server

```bash
savant-context run
```

Expected output:
```
Starting Savant Context MCP server...
MCP server running. Press Ctrl+C to stop.
```

The server now listens on stdin/stdout for MCP requests.

## Using with Claude Desktop

### 1. Find Your Config Location

Create or edit Claude Desktop config:
- macOS: `~/Library/Application Support/Claude/claude_desktop_config.json`
- Windows: `%APPDATA%\Claude\claude_desktop_config.json`
- Linux: `~/.config/Claude/claude_desktop_config.json`

### 2. Add MCP Server Configuration

```json
{
  "mcpServers": {
    "savant-context": {
      "command": "savant-context",
      "args": ["run"]
    }
  }
}
```

### 3. Restart Claude Desktop

Close and reopen Claude Desktop. You should see "savant-context" in the MCP servers section.

### 4. Use Search

In Claude Desktop, you can now use the savant-context tools:

```
Search for "function decorator" in savant-mvp

or

List all indexed repositories

or

Show stats for savant-mvp repository
```

## Common Workflows

### Index Multiple Repositories

```bash
# Index project-a
savant-context index:repo ~/projects/project-a --name project-a

# Index project-b
savant-context index:repo ~/projects/project-b --name project-b

# Index project-c
savant-context index:repo ~/projects/project-c --name project-c

# View all indexed
savant-context status
```

### Backup and Restore

```bash
# Create a backup
savant-context db:dump ~/my-index-backup.dump

# Later, restore from backup
savant-context db:restore ~/my-index-backup.dump
```

### Re-index a Repository

```bash
# Just index again - it will update existing data
savant-context index:repo ~/projects/project-a
```

## Troubleshooting

### "PostgreSQL connection failed"

```bash
# Check if PostgreSQL is running
brew services list

# Start PostgreSQL if needed
brew services start postgresql@14

# Test connection
psql -U $(whoami) -d postgres
```

### "pg_dump command not found"

```bash
# Install PostgreSQL client tools
brew install postgresql@14
```

### "ModuleNotFoundError: No module named 'mcp'"

```bash
# Reinstall package dependencies
pip install -e .
```

### Database already exists

If you get "database already exists" error:

```bash
# Drop existing database (WARNING: deletes all data)
dropdb -U $(whoami) savant_context

# Then re-run setup
savant-context db:setup
```

## Environment Variables

Customize the database connection:

```bash
# Use custom PostgreSQL server
export POSTGRES_HOST=192.168.1.100
export POSTGRES_PORT=5432
export POSTGRES_DB=my_context_index
export POSTGRES_USER=myuser
export POSTGRES_PASSWORD=mypassword

# Then run commands
savant-context db:setup
savant-context index:repo ~/projects/my-project
```

## Next Steps

1. **Index your projects** - Run `index:repo` on your codebases
2. **Search from Claude** - Use Claude Desktop to search your code
3. **Explore MCP tools** - Try different search queries and filters
4. **Backup regularly** - Use `db:dump` to back up your index
5. **Monitor status** - Check `status` occasionally

## Performance Tips

### For Large Repositories

```bash
# Index in background if it takes time
savant-context index:repo ~/huge-repo &

# Check progress with status
watch savant-context status
```

### For Better Search Results

- Index multiple related projects to find cross-repo patterns
- Use specific search terms (e.g., "class definition" instead of "class")
- Filter by repository when searching many projects

## Example Searches

Once indexed, you can search for:

- `function definition` - Find function definitions
- `import` - Find import statements
- `class MyClass` - Find specific class definitions
- `error handling` - Find exception handling
- `async/await` - Find async patterns
- `database query` - Find database operations
- `todo` - Find TODO comments

## Support

For issues or questions:

1. Check the README.md for more details
2. Review the plan at `/Users/home/.claude/plans/foamy-inventing-allen.md`
3. Check implementation details in IMPLEMENTATION_SUMMARY.md

## Next Development Steps

Once you've tested the basic functionality:

1. Push to GitHub and create releases
2. Set up Homebrew tap for easy installation
3. Add GitHub Actions for CI/CD
4. Consider adding web UI
5. Explore vector embeddings for semantic search
