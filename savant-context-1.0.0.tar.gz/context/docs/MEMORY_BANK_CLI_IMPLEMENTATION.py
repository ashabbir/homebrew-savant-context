"""
Memory Bank CLI Commands - Example Implementation
Add this to savant_context/cli.py or create savant_context/cli/memory.py

This shows how to implement the memory bank CLI commands.
"""

import click
import json
from typing import Optional
from pathlib import Path

# These would be imports from the main CLI structure
# from .mcp.tools import ToolHandler
# from .db import DatabaseClient


def get_memory_commands_example():
    """
    Example of how to add memory bank command group to main CLI.

    Add this to cli.py main() function:

    @main.group(name="memory")
    def memory() -> None:
        \"\"\"Memory bank management commands.\"\"\"
        pass
    """
    pass


# ============================================================================
# COMMAND 1: memory search
# ============================================================================

MEMORY_SEARCH_EXAMPLE = """
@main.command(name="memory")
@click.group(invoke_without_command=False)
def memory() -> None:
    \"\"\"Memory bank management commands.\"\"\"
    pass


@memory.command(name="search")
@click.argument("query")
@click.option("--repo", default=None, help="Filter by repository")
@click.option("--limit", default=20, type=int, help="Maximum results (1-100)")
@click.option("--format",
    type=click.Choice(["table", "json", "text"]),
    default="table",
    help="Output format")
@click.option("--highlight", is_flag=True, help="Highlight search terms")
def memory_search(query: str, repo: Optional[str], limit: int, format: str, highlight: bool) -> None:
    \"\"\"Search memory bank documents.

    QUERY: Search query (e.g., 'architecture patterns')

    Examples:
        savant-context memory search "architecture"
        savant-context memory search "API design" --repo my-project
        savant-context memory search "patterns" --format json
    \"\"\"
    from savant_context.mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_search(query=query, repo=repo, limit=limit)

        if format == "json":
            click.echo(json.dumps(result, indent=2, default=str))
        elif format == "table":
            _display_memory_search_table(result, highlight)
        else:
            _display_memory_search_text(result)
    finally:
        db_client.close()


def _display_memory_search_table(result, highlight=False):
    \"\"\"Display search results as a formatted table.\"\"\"
    click.echo()
    click.echo("=" * 90)
    click.echo("MEMORY BANK SEARCH RESULTS")
    click.echo("=" * 90)

    if not result.get("results"):
        click.echo("No results found.")
        return

    click.echo(f"{'Repo':<15} {'File':<30} {'Rank':<8} Preview")
    click.echo("-" * 90)

    for r in result["results"]:
        repo = r.get("repo", "?")[:15]
        path = r.get("file_path", "?")[-30:]
        rank = f\"{r.get('rank', 0):.2f}\"
        content_preview = r.get("content", "")[:35].replace("\\n", " ")

        click.echo(f"{repo:<15} {path:<30} {rank:<8} {content_preview}...")


def _display_memory_search_text(result):
    \"\"\"Display search results as plain text.\"\"\"
    click.echo()
    click.echo("MEMORY BANK SEARCH RESULTS")
    click.echo("-" * 50)

    for r in result["results"]:
        click.echo(f\"\\nFile: {r.get('file_path')}\")
        click.echo(f\"Repo: {r.get('repo')}\")
        click.echo(f\"Chunk: {r.get('chunk_index')}\")
        click.echo(f\"Rank: {r.get('rank')}\")
        click.echo(f\"Content:\\n{r.get('content')[:200]}...\")
"""


# ============================================================================
# COMMAND 2: memory list
# ============================================================================

MEMORY_LIST_EXAMPLE = """
@memory.command(name="list")
@click.option("--repo", default=None, help="Filter by repository")
@click.option("--sort",
    type=click.Choice(["name", "size", "created", "updated"]),
    default="name",
    help="Sort by field")
@click.option("--format",
    type=click.Choice(["table", "json", "tree"]),
    default="table",
    help="Output format")
@click.option("--show-chunks", is_flag=True, help="Include chunk count")
def memory_list(repo: Optional[str], sort: str, format: str, show_chunks: bool) -> None:
    \"\"\"List all memory bank resources.

    Examples:
        savant-context memory list
        savant-context memory list --repo my-project
        savant-context memory list --format tree --show-chunks
    \"\"\"
    from savant_context.mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_resources_list(repo=repo)

        if format == "json":
            click.echo(json.dumps(result, indent=2, default=str))
        elif format == "tree":
            _display_memory_list_tree(result, sort, show_chunks)
        else:
            _display_memory_list_table(result, sort, show_chunks)
    finally:
        db_client.close()


def _display_memory_list_table(result, sort: str, show_chunks: bool):
    \"\"\"Display memory bank files as a table.\"\"\"
    click.echo()
    click.echo("=" * 90)
    click.echo("MEMORY BANK RESOURCES")
    click.echo("=" * 90)

    resources = result.get("resources", [])
    if not resources:
        click.echo("No memory bank files found.")
        return

    # Sort resources
    sort_key = {
        "name": lambda r: r.get("path", ""),
        "size": lambda r: r.get("chunk_count", 0),
        "created": lambda r: r.get("created_at", ""),
        "updated": lambda r: r.get("indexed_at", ""),
    }.get(sort, lambda r: r.get("path", ""))

    sorted_resources = sorted(resources, key=sort_key)

    # Display
    if show_chunks:
        header = f\"{'Repo':<15} {'File Path':<35} {'Chunks':<8} Updated\"
        click.echo(header)
        click.echo("-" * 90)
        for r in sorted_resources:
            click.echo(f\"{r.get('repo', '?'):<15} {r.get('path', '?'):<35} {r.get('chunk_count', 0):<8} {r.get('indexed_at', '')}\")
    else:
        header = f\"{'Repo':<15} {'File Path':<50} Updated\"
        click.echo(header)
        click.echo("-" * 90)
        for r in sorted_resources:
            click.echo(f\"{r.get('repo', '?'):<15} {r.get('path', '?'):<50} {r.get('indexed_at', '')}\")


def _display_memory_list_tree(result, sort: str, show_chunks: bool):
    \"\"\"Display memory bank files as a tree structure.\"\"\"
    click.echo()
    click.echo("=" * 90)
    click.echo("MEMORY BANK RESOURCES (TREE VIEW)")
    click.echo("=" * 90)

    # Group by repo
    repos = {}
    for resource in result.get("resources", []):
        repo = resource.get("repo", "unknown")
        if repo not in repos:
            repos[repo] = []
        repos[repo].append(resource)

    # Display tree
    for repo_name in sorted(repos.keys()):
        click.echo(f"{repo_name}/")
        resources = repos[repo_name]
        for i, resource in enumerate(sorted(resources, key=lambda r: r.get("path", ""))):
            is_last = i == len(resources) - 1
            prefix = "└── " if is_last else "├── "

            path_parts = resource.get("path", "").split("/")
            display_path = "/".join(path_parts[-2:])  # Show last 2 parts

            if show_chunks:
                chunks = resource.get("chunk_count", 0)
                click.echo(f"  {prefix}{display_path} ({chunks} chunks)")
            else:
                click.echo(f"  {prefix}{display_path}")
"""


# ============================================================================
# COMMAND 3: memory read
# ============================================================================

MEMORY_READ_EXAMPLE = """
@memory.command(name="read")
@click.argument("uri")
@click.option("--raw", is_flag=True, help="Output raw markdown without formatting")
@click.option("--less", is_flag=True, help="Pipe to less pager")
@click.option("--format",
    type=click.Choice(["markdown", "text", "html"]),
    default="markdown",
    help="Output format")
@click.option("--line-numbers", is_flag=True, help="Show line numbers")
def memory_read(uri: str, raw: bool, less: bool, format: str, line_numbers: bool) -> None:
    \"\"\"Read a memory bank document by URI.

    URI: Resource URI in format 'repo:path' or just 'path'

    Examples:
        savant-context memory read "memory_bank/architecture.md"
        savant-context memory read "my-project:memory_bank/api.md"
        savant-context memory read memory_bank/design.md --less
        savant-context memory read memory_bank/api.md --format html
    \"\"\"
    from savant_context.mcp.tools import ToolHandler
    import subprocess

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_resources_read(uri=uri)

        if "error" in result:
            click.echo(f"Error: {result['error']}", err=True)
            raise click.Abort()

        content = result.get("content", "")

        # Add line numbers if requested
        if line_numbers and not raw:
            lines = content.split("\\n")
            content = "\\n".join(f"{i+1:4d} | {line}" for i, line in enumerate(lines))

        # Format content
        if format == "html":
            # Would need markdown2 library
            output = f"<h1>{result.get('path')}</h1>\\n<pre>{content}</pre>"
        else:
            output = content if raw else f"# {result.get('path')}\\n\\n{content}"

        # Pipe to less if requested
        if less:
            try:
                process = subprocess.Popen(["less"], stdin=subprocess.PIPE, text=True)
                process.communicate(input=output)
            except FileNotFoundError:
                click.echo(output)
        else:
            click.echo(output)
    finally:
        db_client.close()
"""


# ============================================================================
# COMMAND 4: memory stats
# ============================================================================

MEMORY_STATS_EXAMPLE = """
@memory.command(name="stats")
@click.option("--repo", default=None, help="Filter by repository")
@click.option("--format",
    type=click.Choice(["table", "json"]),
    default="table",
    help="Output format")
@click.option("--detail", is_flag=True, help="Show detailed breakdown")
def memory_stats(repo: Optional[str], format: str, detail: bool) -> None:
    \"\"\"Show memory bank statistics.

    Examples:
        savant-context memory stats
        savant-context memory stats --repo my-project --detail
        savant-context memory stats --format json
    \"\"\"
    db_client = get_db_client()

    try:
        # Query memory bank stats
        if repo:
            stats = db_client.fetch_all(\"\"\"
                SELECT r.name, COUNT(f.id) as file_count, COUNT(c.id) as chunk_count
                FROM files f
                JOIN repos r ON f.repo_id = r.id
                LEFT JOIN chunks c ON f.id = c.file_id
                WHERE f.is_memory_bank = TRUE AND r.name = %s
                GROUP BY r.name
            \"\"\", (repo,))
        else:
            stats = db_client.fetch_all(\"\"\"
                SELECT r.name, COUNT(f.id) as file_count, COUNT(c.id) as chunk_count
                FROM files f
                JOIN repos r ON f.repo_id = r.id
                LEFT JOIN chunks c ON f.id = c.file_id
                WHERE f.is_memory_bank = TRUE
                GROUP BY r.name
            \"\"\")

        if format == "json":
            click.echo(json.dumps([dict(s) for s in stats], indent=2, default=str))
        else:
            _display_memory_stats_table(stats, detail)
    finally:
        db_client.close()


def _display_memory_stats_table(stats, detail: bool):
    \"\"\"Display memory bank statistics as a table.\"\"\"
    click.echo()
    click.echo("=" * 80)
    click.echo("MEMORY BANK STATISTICS")
    click.echo("=" * 80)

    total_files = sum(s.get("file_count", 0) for s in stats)
    total_chunks = sum(s.get("chunk_count", 0) for s in stats)

    click.echo(f"Total Repositories:  {len(stats)}")
    click.echo(f"Total Files:         {total_files}")
    click.echo(f"Total Chunks:        {total_chunks}")

    if detail and stats:
        click.echo()
        click.echo("BY REPOSITORY:")
        click.echo("-" * 80)
        click.echo(f\"{'Repo':<25} {'Files':<10} {'Chunks':<10}\")
        click.echo("-" * 80)
        for stat in stats:
            click.echo(f\"{stat.get('name', '?'):<25} {stat.get('file_count', 0):<10} {stat.get('chunk_count', 0):<10}\")
"""


# ============================================================================
# INTEGRATION INSTRUCTIONS
# ============================================================================

INTEGRATION_INSTRUCTIONS = """
# How to Integrate Memory Bank Commands into CLI

## Step 1: Create Memory Module (Optional)
Create savant_context/cli/memory.py with all the command functions.

## Step 2: Update cli.py

Add these imports at the top:
```python
import json
from pathlib import Path
```

Add this command group before the @main.group() definition for 'db':

```python
@main.group(name="memory")
def memory() -> None:
    \"\"\"Memory bank management commands.\"\"\"
    pass
```

Then add all the @memory.command() functions below (search, list, read, stats, etc.)

## Step 3: Update Banner

Update the BANNER string in cli.py to include:

```
 CLI Commands:
   ...existing commands...
   savant-context memory search <query>   Search memory bank
   savant-context memory list             List memory bank files
   savant-context memory read <uri>       Read memory bank document
   savant-context memory stats            Show statistics
```

## Step 4: Test

Test the new commands:

```bash
# Install in development mode
pip install -e .

# Test search
savant-context memory search "architecture"

# Test list
savant-context memory list

# Test read
savant-context memory read "memory_bank/architecture.md"

# Test stats
savant-context memory stats
```

## Step 5: Help Text

All commands will have built-in help:

```bash
savant-context memory --help
savant-context memory search --help
savant-context memory list --help
```
"""


if __name__ == "__main__":
    print("Memory Bank CLI Commands - Implementation Examples")
    print("=" * 80)
    print()
    print("This file contains example implementations for:")
    print("1. memory search - Search memory bank documents")
    print("2. memory list - List all memory bank files")
    print("3. memory read - Read a memory bank document")
    print("4. memory stats - Show statistics")
    print()
    print("For full integration instructions, see INTEGRATION_INSTRUCTIONS above.")
    print()
    print("To implement:")
    print("1. Copy the command functions to savant_context/cli.py")
    print("2. Add the @main.group() decorator for 'memory'")
    print("3. Add helper functions for table/tree display")
    print("4. Test with: savant-context memory <command>")
