"""Configuration module using environment variables."""

import os
from typing import Optional


class Config:
    """Configuration loaded from environment variables."""

    # PostgreSQL configuration
    POSTGRES_HOST: str = os.getenv("POSTGRES_HOST", "localhost")
    POSTGRES_PORT: int = int(os.getenv("POSTGRES_PORT", "5432"))
    POSTGRES_DB: str = os.getenv("POSTGRES_DB", "savant-context-standalone")
    POSTGRES_USER: str = os.getenv("POSTGRES_USER", os.getenv("USER", "postgres"))
    POSTGRES_PASSWORD: Optional[str] = os.getenv("POSTGRES_PASSWORD")

    # Logging
    LOG_LEVEL: str = os.getenv("LOG_LEVEL", "info").upper()

    @classmethod
    def get_connection_string(cls) -> str:
        """Generate PostgreSQL connection string."""
        if cls.POSTGRES_PASSWORD:
            return (
                f"postgresql://{cls.POSTGRES_USER}:{cls.POSTGRES_PASSWORD}"
                f"@{cls.POSTGRES_HOST}:{cls.POSTGRES_PORT}/{cls.POSTGRES_DB}"
            )
        else:
            return (
                f"postgresql://{cls.POSTGRES_USER}"
                f"@{cls.POSTGRES_HOST}:{cls.POSTGRES_PORT}/{cls.POSTGRES_DB}"
            )

    @classmethod
    def get_admin_connection_string(cls) -> str:
        """Generate PostgreSQL connection string without database (for creating DB)."""
        if cls.POSTGRES_PASSWORD:
            return (
                f"postgresql://{cls.POSTGRES_USER}:{cls.POSTGRES_PASSWORD}"
                f"@{cls.POSTGRES_HOST}:{cls.POSTGRES_PORT}/postgres"
            )
        else:
            return (
                f"postgresql://{cls.POSTGRES_USER}"
                f"@{cls.POSTGRES_HOST}:{cls.POSTGRES_PORT}/postgres"
            )
