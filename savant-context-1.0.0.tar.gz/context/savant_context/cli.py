"""CLI for savant-context."""

import logging
import sys
from pathlib import Path
from typing import Optional

import click

from . import __version__
from .config import Config
from .db import DatabaseClient, init_schema
from .db.operations import dump_database, restore_database, create_database
from .indexer import Indexer
from .mcp.server import MCPServer

# Configure logging to stderr only
# This keeps stdout clean for MCP JSON-RPC compliance in server mode
logging.basicConfig(
    level=logging.ERROR,  # Only show errors by default to keep output clean
    format="%(name)s - %(levelname)s - %(message)s",
    stream=sys.stderr,
)
logger = logging.getLogger(__name__)

# ASCII Art
BANNER = """
  ███████╗ █████╗ ██╗   ██╗ █████╗ ██╗   ██╗████████╗
  ██╔════╝██╔══██╗██║   ██║██╔══██╗██║   ██║╚══██╔══╝
  ███████╗███████║██║   ██║███████║██║   ██║   ██║
  ╚════██║██╔══██║╚██╗ ██╔╝██╔══██║██║   ██║   ██║
  ███████║██║  ██║ ╚████╔╝ ██║  ██║╚██████╔╝   ██║
  ╚══════╝╚═╝  ╚═╝  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝    ╚═╝

 Context - MCP Server with Code Indexer
 By AmdSh
 Version: {version}

 CLI Commands:
   savant-context / savant              Show banner
   savant-context run / savant           Start MCP server
   savant-context db setup              Initialize database
   savant-context db dump <path>        Backup database
   savant-context db restore <path>     Restore database
   savant-context db destroy            Delete database
   savant-context db psql               Open psql shell
   savant-context index repo [path]     Index repository
   savant-context status                Show indexing status
   savant-context readme                Show documentation

 MCP Tools:
   fts_search                 Full-text search across repos
   memory_search              Search memory bank markdown
   memory_resources_list      List memory bank resources
   memory_resources_read      Read resource by URI
   repos_list                 List repos with README excerpts
   fs_repo_status             Show per-repo index status

 ═══════════════════════════════════════════════════════════════════════════════
"""


def get_db_client() -> DatabaseClient:
    """Get a connected database client."""
    client = DatabaseClient()
    try:
        client.connect()
    except Exception as e:
        click.echo(f"Error: Failed to connect to database: {e}", err=True)
        raise click.Abort()
    return client


def print_banner() -> None:
    """Print the ASCII art banner."""
    click.echo(BANNER.format(version=__version__))


@click.group(invoke_without_command=True)
@click.version_option(version=__version__, prog_name="savant-context")
@click.pass_context
def main(ctx) -> None:
    """Savant Context - Code indexer and MCP server."""
    # Skip banner for commands that require clean output
    # 'run': MCP server (must output ONLY JSON-RPC)
    # 'tool': CLI tool calls (must output ONLY JSON)
    pure_output_commands = {"tool", "run"}

    if ctx.invoked_subcommand not in pure_output_commands:
        print_banner()

    if ctx.invoked_subcommand is None:
        # Print banner when no subcommand given
        pass  # Banner already printed


@main.command()
def run() -> None:
    """Start the MCP server."""
    # MCP spec requires ONLY JSON-RPC on stdout, so no startup messages
    # All output goes to stderr
    click.echo("Starting Savant Context MCP server on stdio transport...", err=True)

    db_client = get_db_client()

    try:
        # Verify schema exists
        if not db_client.table_exists("repos"):
            click.echo("ERROR: Database schema not initialized. Run 'db:setup' first.", err=True)
            db_client.close()
            raise click.Abort()

        # Create and run MCP server
        mcp = MCPServer(db_client)
        click.echo("MCP server initialized. Ready to receive tool calls.", err=True)

        try:
            mcp.run()
        except KeyboardInterrupt:
            click.echo("MCP server shutting down...", err=True)
        finally:
            db_client.close()

    except Exception as e:
        click.echo(f"ERROR: {e}", err=True)
        raise click.Abort()


@main.group()
def db() -> None:
    """Database management commands."""
    pass


@db.command(name="setup")
def db_setup() -> None:
    """Initialize the database and create schema."""
    click.echo("Setting up database...")

    try:
        # Create database if it doesn't exist
        click.echo("Creating database if needed...")
        create_database()
        click.echo("✓ Database ready")

        # Connect and initialize schema
        db_client = get_db_client()
        init_schema(db_client)
        click.echo("✓ Database schema initialized successfully")
        db_client.close()

    except Exception as e:
        click.echo(f"Error: Failed to initialize database: {e}", err=True)
        raise click.Abort()


@db.command(name="dump")
@click.argument("output_path", type=click.Path())
def db_dump(output_path: str) -> None:
    """Dump the database to a file.

    OUTPUT_PATH: Path where to save the dump file
    """
    output_file = Path(output_path)

    if output_file.exists():
        if not click.confirm(f"File {output_path} exists. Overwrite?"):
            click.echo("Aborted")
            return

    click.echo(f"Dumping database to {output_path}...")

    try:
        dump_database(output_file)
        click.echo(f"✓ Database dumped successfully to {output_path}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="restore")
@click.argument("dump_path", type=click.Path(exists=True))
@click.option("--clean", is_flag=True, help="Drop objects before restoring")
def db_restore(dump_path: str, clean: bool) -> None:
    """Restore the database from a dump file.

    DUMP_PATH: Path to the dump file
    """
    if not click.confirm(f"Restore database from {dump_path}? This will replace existing data."):
        click.echo("Aborted")
        return

    click.echo(f"Restoring database from {dump_path}...")

    try:
        # Create database if it doesn't exist
        click.echo("Creating database if needed...")
        create_database()
        click.echo("✓ Database ready")

        # Restore from dump
        restore_database(Path(dump_path), clean=clean)
        click.echo(f"✓ Database restored successfully from {dump_path}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="destroy")
def db_destroy() -> None:
    """Destroy the database completely.

    WARNING: This permanently deletes all indexed data.
    """
    if not click.confirm("⚠️  This will permanently delete ALL indexed data. Are you sure?"):
        click.echo("Aborted")
        return

    if not click.confirm("Type 'destroy' to confirm permanent deletion"):
        click.echo("Aborted")
        return

    click.echo("Destroying database...")

    try:
        db_client = get_db_client()

        # Drop all tables
        db_client.execute("DROP TABLE IF EXISTS chunks CASCADE")
        db_client.execute("DROP TABLE IF EXISTS files CASCADE")
        db_client.execute("DROP TABLE IF EXISTS repos CASCADE")

        click.echo("✓ Database destroyed successfully")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="psql")
def db_psql() -> None:
    """Open psql shell to the database."""
    import subprocess

    try:
        # Build psql command
        cmd = [
            "psql",
            "-h", Config.POSTGRES_HOST,
            "-p", str(Config.POSTGRES_PORT),
            "-U", Config.POSTGRES_USER,
            "-d", Config.POSTGRES_DB,
        ]

        click.echo(f"Connecting to PostgreSQL at {Config.POSTGRES_HOST}:{Config.POSTGRES_PORT}/{Config.POSTGRES_DB}...")

        # Execute psql
        subprocess.run(cmd, check=False)

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@main.command()
def status() -> None:
    """Show detailed status of indexed repositories."""
    db_client = get_db_client()

    try:
        # Check if schema exists
        if not db_client.table_exists("repos"):
            click.echo("No repositories indexed yet. Run 'index repo' to start indexing.")
            return

        # Get repository stats with language breakdown
        repos = db_client.fetch_all(
            """
            SELECT
                r.id,
                r.name,
                r.indexed_at,
                COUNT(DISTINCT f.id) as file_count,
                COUNT(DISTINCT c.id) as chunk_count
            FROM repos r
            LEFT JOIN files f ON r.id = f.repo_id
            LEFT JOIN chunks c ON f.id = c.file_id
            GROUP BY r.id, r.name, r.indexed_at
            ORDER BY r.name
            """
        )

        if not repos:
            click.echo("No repositories indexed yet. Run 'index repo' to start indexing.")
            return

        # Display repository header
        click.echo("\n" + "=" * 100)
        click.echo("📊 REPOSITORY STATUS")
        click.echo("=" * 100)


        for repo in repos:
            repo_id = repo["id"]
            repo_name = repo["name"]
            file_count = repo["file_count"] or 0
            chunk_count = repo["chunk_count"] or 0
            indexed_at = repo["indexed_at"] or "Never"

            # Get language breakdown for this repo
            lang_stats = db_client.fetch_all(
                """
                SELECT language, COUNT(*) as count
                FROM files
                WHERE repo_id = %s
                GROUP BY language
                ORDER BY count DESC
                """,
                (repo_id,)
            )

            click.echo(f"\n📁 {repo_name}")
            click.echo("─" * 100)
            click.echo(f"  Last Indexed: {indexed_at}")
            click.echo(f"  Files (Memory Bank): {file_count:,}")
            click.echo(f"  Chunks (FTS Index): {chunk_count:,}")

            # Show file breakdown by type
            if lang_stats:
                click.echo(f"  Files by Type:")
                for lang_stat in lang_stats:
                    lang = lang_stat["language"] or "unknown"
                    count = lang_stat["count"]
                    percentage = (count / file_count * 100) if file_count > 0 else 0
                    click.echo(f"    • {lang:<15} {count:>6,} files ({percentage:>5.1f}%)")

        click.echo("\n" + "=" * 100 + "\n")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@main.group()
def index() -> None:
    """Repository indexing commands."""
    pass


@index.command(name="repo")
@click.argument("path", type=click.Path(exists=True, file_okay=False, dir_okay=True), required=False, default=".")
@click.option("--name", default=None, help="Repository name (default: folder name)")
def index_repo(path: str, name: Optional[str]) -> None:
    """Index a repository.

    PATH: Path to the repository to index (default: current directory)
    """
    repo_path = Path(path).resolve()
    repo_name = name or repo_path.name

    click.echo(f"Indexing repository: {repo_name}")
    click.echo(f"Path: {repo_path}")

    db_client = get_db_client()

    try:
        # Check if schema exists
        if not db_client.table_exists("repos"):
            click.echo("Database schema not initialized. Run 'db:setup' first.", err=True)
            raise click.Abort()

        indexer = Indexer(db_client)
        result = indexer.index_repository(repo_path, repo_name=repo_name, verbose=True)

        click.echo("\n✓ Indexing complete")
        click.echo(f"  Files indexed: {result['files_indexed']}")
        click.echo(f"  Chunks indexed: {result['chunks_indexed']}")
        if result["errors"]:
            click.echo(f"  Errors: {result['errors']}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@main.command()
def readme() -> None:
    """Display the full README documentation."""
    # Try multiple paths to find README
    possible_paths = [
        Path(__file__).parent.parent / "README.md",  # Development mode
        Path(__file__).parent.parent.parent / "README.md",  # Installed in site-packages
        Path("/opt/homebrew/Cellar/savant-context").glob("*/README.md"),  # Homebrew install
    ]

    readme_path = None
    for path in possible_paths:
        if isinstance(path, Path) and path.exists():
            readme_path = path
            break
        elif hasattr(path, '__iter__'):
            try:
                readme_path = next(path)
                break
            except StopIteration:
                continue

    if not readme_path or (isinstance(readme_path, Path) and not readme_path.exists()):
        # Fallback: Show a basic help message
        click.echo("Savant Context - MCP Server with Code Indexer")
        click.echo("")
        click.echo("For more information, visit: https://github.com/ashabbir/context")
        click.echo("")
        click.echo("Available commands:")
        click.echo("  savant-context run              Start MCP server")
        click.echo("  savant-context db setup         Initialize database")
        click.echo("  savant-context index repo       Index a repository")
        click.echo("  savant-context status           Show repository status")
        click.echo("  savant-context tool fts_search  Search indexed code")
        return

    try:
        with open(readme_path, "r", encoding="utf-8") as f:
            content = f.read()
        click.echo(content)
    except Exception as e:
        click.echo(f"Error reading README: {e}", err=True)
        raise click.Abort()


@main.group()
def tool() -> None:
    """Call MCP tools directly from CLI."""
    pass


@tool.command(name="fts_search")
@click.argument("query")
@click.option("--repo", default=None, help="Optional repository name")
@click.option("--limit", default=10, help="Maximum results (1-100)")
def tool_fts_search(query: str, repo: Optional[str], limit: int) -> None:
    """Full-text search across indexed repos.

    QUERY: Search query (e.g., 'def function_name')
    """
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.fts_search(query=query, repo=repo, limit=limit)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="memory_search")
@click.argument("query")
@click.option("--repo", default=None, help="Optional repository name")
@click.option("--limit", default=20, help="Maximum results (1-100)")
def tool_memory_search(query: str, repo: Optional[str], limit: int) -> None:
    """Search memory bank markdown in DB FTS.

    QUERY: Search query
    """
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_search(query=query, repo=repo, limit=limit)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="memory_resources_list")
@click.option("--repo", default=None, help="Optional repository name")
def tool_memory_resources_list(repo: Optional[str]) -> None:
    """List memory bank resources from DB."""
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_resources_list(repo=repo)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="memory_resources_read")
@click.argument("uri")
def tool_memory_resources_read(uri: str) -> None:
    """Read a memory bank resource by URI.

    URI: Resource URI (file path)
    """
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.memory_resources_read(uri=uri)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="repos_list")
@click.option("--filter", default=None, help="Optional repository name filter")
@click.option("--max-length", default=4096, help="Maximum excerpt length")
def tool_repos_list(filter: Optional[str], max_length: int) -> None:
    """List indexed repos with README excerpts."""
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.repos_list(filter=filter, max_length=max_length)

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@tool.command(name="fs_repo_status")
def tool_fs_repo_status() -> None:
    """List per-repo index status counts."""
    from .mcp.tools import ToolHandler

    db_client = get_db_client()

    try:
        handler = ToolHandler(db_client)
        result = handler.fs_repo_status()

        import json
        click.echo(json.dumps(result, indent=2, default=str))
    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


def savant_shortcut() -> None:
    """Shortcut command that automatically runs the MCP server."""
    import sys
    # Insert 'run' as the first argument after 'savant'
    sys.argv.insert(1, 'run')
    main()


if __name__ == "__main__":
    main()
