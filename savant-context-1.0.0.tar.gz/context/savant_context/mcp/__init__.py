"""MCP (Model Context Protocol) server module."""

from .server import MCPServer

__all__ = ["MCPServer"]
