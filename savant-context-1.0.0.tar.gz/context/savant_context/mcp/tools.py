"""MCP tool implementations for Context service.

Implements the 6 core tools from the original MVP:
- fts_search: Full-text search across indexed code
- memory_search: Search memory bank markdown
- memory_resources_list: List memory bank resources
- memory_resources_read: Read specific memory bank resource
- repos_list: List indexed repos with stats
- fs_repo_status: List per-repo index status
"""

import logging
from typing import Any, Dict, List, Optional, Union

from ..db.client import DatabaseClient
from ..indexer.indexer import Indexer

logger = logging.getLogger(__name__)


class ToolHandler:
    """Handles MCP tool calls for Context service."""

    def __init__(self, db_client: DatabaseClient):
        """Initialize tool handler.

        Args:
            db_client: DatabaseClient instance
        """
        self.db = db_client
        self.indexer = Indexer(db_client)

    def fts_search(
        self,
        q: Optional[str] = None,
        query: Optional[str] = None,
        repo: Optional[Union[str, List[str]]] = None,
        limit: int = 10,
        exclude_memory_bank: bool = False,
    ) -> Dict[str, Any]:
        """Full-text search over indexed repos (filter by repo name(s)).

        Args:
            q: Search query (alternate parameter name)
            query: Search query
            repo: Optional repository name or list of names to filter
            limit: Maximum results (1-100, default 10)
            exclude_memory_bank: If True, exclude memory bank documents

        Returns:
            Search results with rank
        """
        try:
            # Accept both 'q' and 'query' parameters
            search_query = (q or query or "").strip()
            if not search_query:
                return {"error": "query required", "results": []}

            # Normalize limit
            try:
                limit = max(1, min(100, int(limit)))
            except (ValueError, TypeError):
                limit = 10

            # Build SQL query
            sql = """
                SELECT
                    r.name as repo,
                    f.rel_path as file_path,
                    f.language,
                    f.is_memory_bank,
                    c.chunk_index,
                    c.content,
                    ts_rank(c.content_vector, plainto_tsquery('english', %s)) as rank
                FROM chunks c
                JOIN files f ON c.file_id = f.id
                JOIN repos r ON f.repo_id = r.id
                WHERE c.content_vector @@ plainto_tsquery('english', %s)
            """
            params: List[Any] = [search_query, search_query]

            # Handle repo filter (single string or list)
            if repo:
                repo_list = repo if isinstance(repo, list) else [repo]
                repo_list = [str(r).strip() for r in repo_list if r]
                if repo_list:
                    placeholders = ",".join(["%s"] * len(repo_list))
                    sql += f" AND r.name IN ({placeholders})"
                    params.extend(repo_list)

            # Handle memory bank exclusion
            if exclude_memory_bank:
                sql += " AND f.is_memory_bank = FALSE"

            sql += " ORDER BY rank DESC LIMIT %s"
            params.append(limit)

            results = self.db.fetch_all(sql, tuple(params))

            return {
                "query": search_query,
                "repo_filter": repo,
                "exclude_memory_bank": exclude_memory_bank,
                "result_count": len(results),
                "results": [dict(r) for r in results] if results else [],
            }
        except Exception as e:
            logger.error(f"FTS search failed: {e}")
            return {"error": str(e), "query": q or query, "results": []}

    def memory_search(
        self,
        q: Optional[str] = None,
        query: Optional[str] = None,
        repo: Optional[Union[str, List[str]]] = None,
        limit: int = 20,
    ) -> Dict[str, Any]:
        """Search memory bank markdown in DB FTS (filter by repo name(s)).

        Args:
            q: Search query (alternate parameter name)
            query: Search query
            repo: Optional repository name or list of names to filter
            limit: Maximum results (1-100, default 20)

        Returns:
            Memory bank search results
        """
        try:
            # Accept both 'q' and 'query' parameters
            search_query = (q or query or "").strip()
            if not search_query:
                return {"error": "query required", "results": []}

            # Normalize limit
            try:
                limit = max(1, min(100, int(limit)))
            except (ValueError, TypeError):
                limit = 20

            # Build SQL query - filter to memory bank documents only
            sql = """
                SELECT
                    r.name as repo,
                    f.rel_path as file_path,
                    f.language,
                    f.is_memory_bank,
                    c.chunk_index,
                    c.content,
                    ts_rank(c.content_vector, plainto_tsquery('english', %s)) as rank
                FROM chunks c
                JOIN files f ON c.file_id = f.id
                JOIN repos r ON f.repo_id = r.id
                WHERE c.content_vector @@ plainto_tsquery('english', %s)
                AND f.is_memory_bank = TRUE
            """
            params: List[Any] = [search_query, search_query]

            # Handle repo filter (single string or list)
            if repo:
                repo_list = repo if isinstance(repo, list) else [repo]
                repo_list = [str(r).strip() for r in repo_list if r]
                if repo_list:
                    placeholders = ",".join(["%s"] * len(repo_list))
                    sql += f" AND r.name IN ({placeholders})"
                    params.extend(repo_list)

            sql += " ORDER BY rank DESC LIMIT %s"
            params.append(limit)

            results = self.db.fetch_all(sql, tuple(params))

            return {
                "query": search_query,
                "repo_filter": repo,
                "result_count": len(results),
                "results": [dict(r) for r in results] if results else [],
            }
        except Exception as e:
            logger.error(f"Memory search failed: {e}")
            return {"error": str(e), "query": q or query, "results": []}

    def memory_resources_list(
        self, repo: Optional[Union[str, List[str]]] = None
    ) -> Dict[str, Any]:
        """List memory bank resources from DB (optional repo filter).

        Args:
            repo: Optional repository name or list of names to filter

        Returns:
            List of memory bank resources
        """
        try:
            sql = """
                SELECT
                    r.name as repo,
                    f.rel_path as path,
                    f.language,
                    f.is_memory_bank,
                    COUNT(c.id) as chunk_count,
                    f.indexed_at,
                    f.created_at
                FROM files f
                JOIN repos r ON f.repo_id = r.id
                LEFT JOIN chunks c ON f.id = c.file_id
                WHERE f.is_memory_bank = TRUE
            """
            params: List[Any] = []

            # Handle repo filter
            if repo:
                repo_list = repo if isinstance(repo, list) else [repo]
                repo_list = [str(r).strip() for r in repo_list if r]
                if repo_list:
                    placeholders = ",".join(["%s"] * len(repo_list))
                    sql += f" AND r.name IN ({placeholders})"
                    params.extend(repo_list)

            sql += " GROUP BY r.name, f.id, f.rel_path, f.language, f.is_memory_bank, f.indexed_at, f.created_at ORDER BY r.name, f.rel_path"

            resources = self.db.fetch_all(sql, tuple(params) if params else ())

            # Format resources with URI
            formatted_resources = []
            for resource in resources:
                resource_dict = dict(resource)
                # Create URI from repo:path format
                resource_dict["uri"] = f"{resource_dict['repo']}:{resource_dict['path']}"
                formatted_resources.append(resource_dict)

            return {
                "resource_count": len(formatted_resources),
                "repo_filter": repo,
                "resources": formatted_resources,
            }
        except Exception as e:
            logger.error(f"Memory resources list failed: {e}")
            return {"error": str(e), "resources": []}

    def memory_resources_read(self, uri: str) -> Dict[str, Any]:
        """Read a memory bank resource by URI.

        Args:
            uri: Resource URI in format "repo:path" or just path

        Returns:
            Resource content
        """
        try:
            uri = (uri or "").strip()
            if not uri:
                return {"error": "uri required"}

            # Parse URI - supports both "repo:path" and just "path"
            if ":" in uri:
                repo_name, rel_path = uri.split(":", 1)
                repo_name = repo_name.strip()
                rel_path = rel_path.strip()
            else:
                rel_path = uri
                repo_name = None

            # Find file by rel_path and memory bank flag
            if repo_name:
                file_record = self.db.fetch_one(
                    """
                    SELECT f.id, f.repo_id, f.rel_path, f.language, f.is_memory_bank, f.created_at
                    FROM files f
                    JOIN repos r ON f.repo_id = r.id
                    WHERE f.rel_path = %s AND r.name = %s AND f.is_memory_bank = TRUE
                    """,
                    (rel_path, repo_name),
                )
            else:
                file_record = self.db.fetch_one(
                    """
                    SELECT f.id, f.repo_id, f.rel_path, f.language, f.is_memory_bank, f.created_at
                    FROM files f
                    WHERE f.rel_path = %s AND f.is_memory_bank = TRUE
                    """,
                    (rel_path,),
                )

            if not file_record:
                return {"error": f"Memory bank resource not found: {uri}"}

            file_id = file_record["id"]
            repo_id = file_record["repo_id"]

            # Get repo name if not already set
            if not repo_name:
                repo_record = self.db.fetch_one("SELECT name FROM repos WHERE id = %s", (repo_id,))
                repo_name = repo_record["name"] if repo_record else "unknown"

            # Get all chunks for this file
            chunks = self.db.fetch_all(
                """
                SELECT chunk_index, content
                FROM chunks
                WHERE file_id = %s
                ORDER BY chunk_index
                """,
                (file_id,),
            )

            # Reconstruct content
            content = ""
            if chunks:
                content = "\n".join([chunk["content"] for chunk in chunks])

            return {
                "uri": uri,
                "repo": repo_name,
                "path": file_record["rel_path"],
                "language": file_record["language"],
                "is_memory_bank": file_record["is_memory_bank"],
                "content": content,
                "chunk_count": len(chunks) if chunks else 0,
                "created_at": str(file_record["created_at"]) if file_record["created_at"] else None,
            }
        except Exception as e:
            logger.error(f"Memory resources read failed: {e}")
            return {"error": str(e), "uri": uri}

    def repos_list(self, filter: Optional[str] = None, max_length: int = 4096) -> Dict[str, Any]:
        """List indexed repos with README excerpts.

        Args:
            filter: Optional filter string (repo name substring)
            max_length: Maximum excerpt length (256-16384, default 4096)

        Returns:
            List of repos with stats
        """
        try:
            # Normalize max_length
            try:
                max_length = max(256, min(16384, int(max_length)))
            except (ValueError, TypeError):
                max_length = 4096

            sql = """
                SELECT
                    r.id,
                    r.name,
                    r.path,
                    r.indexed_at,
                    COUNT(DISTINCT f.id) as file_count,
                    COUNT(DISTINCT c.id) as chunk_count
                FROM repos r
                LEFT JOIN files f ON r.id = f.repo_id
                LEFT JOIN chunks c ON f.id = c.file_id
            """
            params: List[Any] = []

            if filter:
                sql += " WHERE r.name ILIKE %s"
                params.append(f"%{filter}%")

            sql += " GROUP BY r.id, r.name, r.path, r.indexed_at ORDER BY r.name"

            repos = self.db.fetch_all(sql, tuple(params) if params else ())

            result_repos = []
            for repo in repos:
                repo_dict = dict(repo)
                # Try to get README excerpt
                readme_record = self.db.fetch_one(
                    "SELECT content FROM chunks WHERE file_id IN "
                    "(SELECT id FROM files WHERE repo_id = %s AND rel_path ILIKE %s) "
                    "LIMIT 1",
                    (repo["id"], "%readme%"),
                )
                if readme_record:
                    content = readme_record["content"]
                    repo_dict["readme_excerpt"] = content[:max_length]
                result_repos.append(repo_dict)

            return {
                "repo_count": len(result_repos),
                "filter": filter,
                "repos": result_repos,
            }
        except Exception as e:
            logger.error(f"Repos list failed: {e}")
            return {"error": str(e), "repos": []}

    def fs_repo_status(self) -> Dict[str, Any]:
        """List per-repo index status counts.

        Returns:
            Status for each repository
        """
        try:
            stats = self.indexer.get_repository_stats()

            repo_status = []
            for stat in stats:
                repo_status.append({
                    "name": stat.get("name"),
                    "path": stat.get("path"),
                    "indexed_at": stat.get("indexed_at"),
                    "file_count": stat.get("file_count") or 0,
                    "chunk_count": stat.get("chunk_count") or 0,
                    "latest_mtime_ns": stat.get("latest_mtime_ns"),
                })

            return {
                "repo_count": len(repo_status),
                "status": repo_status,
            }
        except Exception as e:
            logger.error(f"Repo status failed: {e}")
            return {"error": str(e), "status": []}


def get_tool_definitions() -> List[Dict[str, Any]]:
    """Get MCP tool definitions for Context service.

    Returns:
        List of 6 tool definitions matching original MVP
    """
    return [
        {
            "name": "fts_search",
            "description": "Full-text search over indexed repos (filter by repo name(s))",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "q": {
                        "type": "string",
                        "description": "Search query",
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query (alternative to 'q')",
                    },
                    "repo": {
                        "anyOf": [
                            {"type": "string"},
                            {"type": "array", "items": {"type": "string"}},
                            {"type": "null"},
                        ],
                        "description": "Optional repo name or list of names to filter",
                    },
                    "limit": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 100,
                        "description": "Maximum results (1-100, default 10)",
                    },
                    "exclude_memory_bank": {
                        "type": "boolean",
                        "description": "If true, exclude memory bank documents (default false)",
                    },
                },
            },
        },
        {
            "name": "memory_search",
            "description": "Search memory bank markdown in DB FTS (filter by repo name(s))",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "q": {
                        "type": "string",
                        "description": "Search query",
                    },
                    "query": {
                        "type": "string",
                        "description": "Search query (alternative to 'q')",
                    },
                    "repo": {
                        "anyOf": [
                            {"type": "string"},
                            {"type": "array", "items": {"type": "string"}},
                            {"type": "null"},
                        ],
                        "description": "Optional repo name or list of names to filter",
                    },
                    "limit": {
                        "type": "integer",
                        "minimum": 1,
                        "maximum": 100,
                        "description": "Maximum results (1-100, default 20)",
                    },
                },
            },
        },
        {
            "name": "memory_resources_list",
            "description": "List memory bank resources from DB (optional repo filter)",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "repo": {
                        "anyOf": [
                            {"type": "string"},
                            {"type": "array", "items": {"type": "string"}},
                            {"type": "null"},
                        ],
                        "description": "Optional repo name or list of names to filter",
                    }
                },
            },
        },
        {
            "name": "memory_resources_read",
            "description": "Read a memory bank resource by URI",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "uri": {
                        "type": "string",
                        "description": "Resource URI (file path)",
                    }
                },
                "required": ["uri"],
            },
        },
        {
            "name": "repos_list",
            "description": "List indexed repos with README excerpts",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "filter": {
                        "type": "string",
                        "description": "Optional repo name substring filter",
                    },
                    "max_length": {
                        "type": "integer",
                        "minimum": 256,
                        "maximum": 16384,
                        "description": "Maximum excerpt length (default 4096)",
                    },
                },
            },
        },
        {
            "name": "fs_repo_status",
            "description": "List per-repo index status counts",
            "inputSchema": {
                "type": "object",
                "properties": {},
            },
        },
    ]
