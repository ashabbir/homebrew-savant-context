"""MCP (Model Context Protocol) server implementation."""

import json
import logging
import sys
from datetime import datetime
from typing import Any, Dict

from ..db.client import DatabaseClient
from .tools import ToolHandler, get_tool_definitions

logger = logging.getLogger(__name__)


class DateTimeEncoder(json.JSONEncoder):
    """JSON encoder that handles datetime objects."""

    def default(self, obj: Any) -> Any:
        """Convert datetime objects to ISO format strings."""
        if isinstance(obj, datetime):
            return obj.isoformat()
        return super().default(obj)


class MCPServer:
    """MCP server for code context and search."""

    def __init__(self, db_client: DatabaseClient):
        """Initialize MCP server.

        Args:
            db_client: DatabaseClient instance
        """
        self.db = db_client
        self.tool_handler = ToolHandler(db_client)

    def run(self) -> None:
        """Run MCP server with stdio transport.

        MCP specification requires ONLY JSON-RPC 2.0 messages on stdout.
        All diagnostic output must go to stderr.

        JSON-RPC 2.0 spec:
        - Request: {"jsonrpc": "2.0", "method": "...", "params": {...}, "id": ...}
        - Response: {"jsonrpc": "2.0", "result": {...}, "id": ...}
        - Error: {"jsonrpc": "2.0", "error": {"code": ..., "message": "..."}, "id": ...}
        """
        logger.debug("MCP server initialized and waiting for JSON-RPC 2.0 requests")

        try:
            while True:
                try:
                    line = input()
                    if not line.strip():
                        continue

                    request = json.loads(line)

                    # Validate JSON-RPC 2.0 structure
                    if not isinstance(request, dict):
                        # Parse error - no valid id available
                        continue

                    jsonrpc = request.get("jsonrpc")
                    method = request.get("method")
                    params = request.get("params", {})
                    req_id = request.get("id")

                    # Check required fields
                    if jsonrpc != "2.0":
                        if req_id is not None:
                            self._send_error(-32600, "Invalid Request: jsonrpc must be 2.0", req_id)
                        continue

                    if not method:
                        if req_id is not None:
                            self._send_error(-32600, "Invalid Request: method is required", req_id)
                        continue

                    logger.debug(f"JSON-RPC method: {method}")

                    # Dispatch to methods
                    if method == "initialize":
                        # MCP initialize method - required by spec
                        # Use MCP capability keys as per spec (tools: list/call)
                        result = {
                            "protocolVersion": "2024-11-05",
                            "capabilities": {
                                "tools": {
                                    "list": {},
                                    "call": {},
                                }
                            },
                            "serverInfo": {
                                "name": "savant-context",
                                "version": "1.0.0",
                            },
                        }
                    elif method == "tools/list":
                        # List available tools
                        result = {
                            "tools": get_tool_definitions(),
                        }
                    elif method == "tools/call":
                        # Call a tool (MCP method)
                        tool_name = params.get("name")
                        tool_args = params.get("arguments", {})
                        tool_result = self._call_tool(tool_name, tool_args)
                        result = self._wrap_tool_result(tool_result)
                    elif method == "fts_search":
                        result = self.tool_handler.fts_search(
                            q=params.get("q"),
                            query=params.get("query"),
                            repo=params.get("repo"),
                            limit=params.get("limit", 10),
                        )
                    elif method == "memory_search":
                        result = self.tool_handler.memory_search(
                            q=params.get("q"),
                            query=params.get("query"),
                            repo=params.get("repo"),
                            limit=params.get("limit", 20),
                        )
                    elif method == "memory_resources_list":
                        result = self.tool_handler.memory_resources_list(
                            repo=params.get("repo")
                        )
                    elif method == "memory_resources_read":
                        result = self.tool_handler.memory_resources_read(
                            uri=params.get("uri", "")
                        )
                    elif method == "repos_list":
                        result = self.tool_handler.repos_list(
                            filter=params.get("filter"),
                            max_length=params.get("max_length", 4096),
                        )
                    elif method == "fs_repo_status":
                        result = self.tool_handler.fs_repo_status()
                    else:
                        self._send_error(-32601, f"Method not found: {method}", req_id)
                        continue

                    # Send JSON-RPC 2.0 response
                    self._send_response(result, req_id)

                except EOFError:
                    # EOF on stdin means client disconnected - graceful shutdown
                    logger.debug("MCP server connection closed (EOF on stdin)")
                    break
                except json.JSONDecodeError as e:
                    self._send_error(-32700, f"Parse error: {e}", None)
                except Exception as e:
                    logger.error(f"Request processing failed: {e}")
                    self._send_error(-32603, f"Internal error: {e}", req_id if 'req_id' in locals() else None)

        except KeyboardInterrupt:
            logger.debug("MCP server shutting down...")

    def _send_response(self, result: Any, req_id: Any) -> None:
        """Send a JSON-RPC 2.0 success response."""
        response = {
            "jsonrpc": "2.0",
            "result": result,
            "id": req_id,
        }
        print(json.dumps(response, cls=DateTimeEncoder))
        sys.stdout.flush()

    def _send_error(self, code: int, message: str, req_id: Any) -> None:
        """Send a JSON-RPC 2.0 error response.

        Note: Only send error response if we have a valid request id.
        """
        if req_id is None:
            # No valid id - don't send error response per JSON-RPC 2.0 spec
            return

        response = {
            "jsonrpc": "2.0",
            "error": {
                "code": code,
                "message": message,
            },
            "id": req_id,
        }
        print(json.dumps(response, cls=DateTimeEncoder))
        sys.stdout.flush()

    def _call_tool(self, tool_name: str, args: Dict[str, Any]) -> Dict[str, Any]:
        """Dispatch tool calls based on tool name."""
        if tool_name == "fts_search":
            return self.tool_handler.fts_search(
                q=args.get("q"),
                query=args.get("query"),
                repo=args.get("repo"),
                limit=args.get("limit", 10),
            )
        elif tool_name == "memory_search":
            return self.tool_handler.memory_search(
                q=args.get("q"),
                query=args.get("query"),
                repo=args.get("repo"),
                limit=args.get("limit", 20),
            )
        elif tool_name == "memory_resources_list":
            return self.tool_handler.memory_resources_list(
                repo=args.get("repo")
            )
        elif tool_name == "memory_resources_read":
            return self.tool_handler.memory_resources_read(
                uri=args.get("uri", "")
            )
        elif tool_name == "repos_list":
            return self.tool_handler.repos_list(
                filter=args.get("filter"),
                max_length=args.get("max_length", 4096),
            )
        elif tool_name == "fs_repo_status":
            return self.tool_handler.fs_repo_status()
        else:
            return {"error": f"Unknown tool: {tool_name}"}

    def _wrap_tool_result(self, data: Any) -> Dict[str, Any]:
        """Wrap tool results in MCP content envelope.

        MCP tools/call responses should include a `content` array with typed items.
        We return JSON results so clients can render or route them reliably.
        """
        is_error = isinstance(data, dict) and "error" in data
        return {
            "content": [
                {
                    "type": "json",
                    "json": data,
                }
            ],
            # Some clients support isError flag to indicate failures
            **({"isError": True} if is_error else {}),
        }
