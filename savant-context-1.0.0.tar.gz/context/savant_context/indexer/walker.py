"""File system walker with .gitignore support."""

import logging
from pathlib import Path
from typing import Iterator, Optional, Set

import pathspec

logger = logging.getLogger(__name__)


class FileWalker:
    """Walk through files respecting .gitignore patterns and auto-skipping non-human-written files."""

    # Common patterns to skip (directories and files)
    DEFAULT_SKIP_PATTERNS = {
        "node_modules",
        ".git",
        ".venv",
        "venv",
        "env",
        "__pycache__",
        ".pytest_cache",
        ".tox",
        "dist",
        "build",
        "*.egg-info",
        ".mypy_cache",
        ".vscode",
        ".idea",
        ".DS_Store",
        "target",
        "out",
        ".next",
        ".nuxt",
        ".cache",
        "coverage",
    }

    # File extensions to skip (binary, compiled, and generated files)
    SKIP_EXTENSIONS = {
        # Compiled Python
        ".pyc",
        ".pyo",
        ".pyd",
        # Compiled C/C++
        ".so",
        ".o",
        ".a",
        ".exe",
        ".dll",
        ".dylib",
        ".lib",
        # Java
        ".class",
        ".jar",
        # Images
        ".jpg",
        ".jpeg",
        ".png",
        ".gif",
        ".bmp",
        ".svg",
        ".ico",
        # Archives
        ".zip",
        ".tar",
        ".gz",
        ".rar",
        ".7z",
        # Binary files
        ".bin",
        ".o",
        ".so",
        # Web builds
        ".wasm",
        ".swf",
        # Lock files (generated)
        ".lock",
        # Minified files (generated)
        ".min.js",
        ".min.css",
        ".min.html",
        # Maps and metadata
        ".map",
        ".d.ts",
        # Generated code
        ".pb.go",
        ".pb.py",
        ".pb.js",
        # Build outputs
        ".out",
        ".o",
    }

    # Filename patterns to skip (generated/temporary files)
    SKIP_FILENAME_PATTERNS = {
        ".eslintcache",
        ".stylelintcache",
        "tsconfig.tsbuildinfo",
        ".coverage",
        ".pytest_cache",
        "package-lock.json",
        "yarn.lock",
        "pnpm-lock.yaml",
        "composer.lock",
        "Gemfile.lock",
        "Pipfile.lock",
        "poetry.lock",
        ".env.local",
        ".env.*.local",
        "dist",
        "build",
        "out",
    }

    def __init__(self, repo_path: Path):
        """Initialize file walker.

        Args:
            repo_path: Root path of repository to walk
        """
        self.repo_path = Path(repo_path).resolve()
        self.gitignore_spec: Optional[pathspec.PathSpec] = None
        self._load_gitignore()

    def _load_gitignore(self) -> None:
        """Load .gitignore patterns if present."""
        gitignore_path = self.repo_path / ".gitignore"

        if gitignore_path.exists():
            try:
                with open(gitignore_path, "r", encoding="utf-8", errors="ignore") as f:
                    patterns = f.read().splitlines()
                self.gitignore_spec = pathspec.PathSpec.from_lines("gitwildmatch", patterns)
                logger.debug(f"Loaded .gitignore from {gitignore_path}")
            except Exception as e:
                logger.warning(f"Failed to load .gitignore: {e}")

    def _should_skip(self, path: Path) -> bool:
        """Check if path should be skipped.

        Args:
            path: Path to check

        Returns:
            True if path should be skipped
        """
        filename = path.name.lower()

        # Check file extension (including compound extensions like .min.js)
        if path.suffix.lower() in self.SKIP_EXTENSIONS:
            return True

        # Check for compound extensions (e.g., .min.js, .d.ts)
        if len(path.suffixes) > 1:
            compound_ext = "".join(path.suffixes).lower()
            if compound_ext in self.SKIP_EXTENSIONS:
                return True

        # Check filename against skip patterns
        if filename in self.SKIP_FILENAME_PATTERNS:
            return True

        # Check directory parts against default skip patterns
        for pattern in self.DEFAULT_SKIP_PATTERNS:
            clean_pattern = pattern.replace("*.", "").replace("*", "")
            if clean_pattern in path.parts:
                return True

        # Check against .gitignore
        if self.gitignore_spec:
            try:
                rel_path = path.relative_to(self.repo_path)
                # gitignore matching is case-sensitive on Unix, case-insensitive on Windows
                if self.gitignore_spec.match_file(str(rel_path)):
                    return True
            except (ValueError, Exception):
                pass

        return False

    def walk(self) -> Iterator[Path]:
        """Yield all non-skipped files in the repository.

        Yields:
            Path: File paths relative to repo root
        """
        try:
            for item in self.repo_path.rglob("*"):
                if item.is_file():
                    if not self._should_skip(item):
                        yield item.relative_to(self.repo_path)
                    else:
                        logger.debug(f"Skipping: {item.relative_to(self.repo_path)}")
        except Exception as e:
            logger.error(f"Error walking repository: {e}")

    def get_file_count(self) -> int:
        """Get total count of files to index.

        Returns:
            Number of files
        """
        return sum(1 for _ in self.walk())
