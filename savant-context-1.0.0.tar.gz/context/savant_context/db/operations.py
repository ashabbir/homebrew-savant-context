"""Database dump and restore operations."""

import logging
import os
import subprocess
from pathlib import Path
from typing import Optional

from ..config import Config

logger = logging.getLogger(__name__)


def create_database() -> None:
    """Create the PostgreSQL database if it doesn't exist.

    Raises:
        subprocess.CalledProcessError: If createdb fails
    """
    logger.info(f"Creating database: {Config.POSTGRES_DB}...")

    # Prepare environment
    env = {}
    if Config.POSTGRES_PASSWORD:
        env["PGPASSWORD"] = Config.POSTGRES_PASSWORD

    cmd = [
        "createdb",
        f"--host={Config.POSTGRES_HOST}",
        f"--port={Config.POSTGRES_PORT}",
        f"--username={Config.POSTGRES_USER}",
        Config.POSTGRES_DB,
    ]

    try:
        subprocess.run(cmd, check=True, env={**os.environ, **env} if env else None, capture_output=True)
        logger.info(f"Database created successfully: {Config.POSTGRES_DB}")
    except subprocess.CalledProcessError as e:
        # Check if database already exists
        if "already exists" in str(e.stderr):
            logger.info(f"Database already exists: {Config.POSTGRES_DB}")
        else:
            logger.error(f"createdb failed: {e}")
            raise
    except FileNotFoundError:
        logger.error("createdb command not found. Make sure PostgreSQL is installed.")
        raise


def dump_database(output_path: Path) -> None:
    """Dump PostgreSQL database to a file.

    Args:
        output_path: Path to save the dump file

    Raises:
        subprocess.CalledProcessError: If pg_dump fails
    """
    logger.info(f"Dumping database to {output_path}...")

    # Prepare environment
    env = {}
    if Config.POSTGRES_PASSWORD:
        env["PGPASSWORD"] = Config.POSTGRES_PASSWORD

    cmd = [
        "pg_dump",
        f"--host={Config.POSTGRES_HOST}",
        f"--port={Config.POSTGRES_PORT}",
        f"--username={Config.POSTGRES_USER}",
        "--format=custom",
        "--file=" + str(output_path),
        Config.POSTGRES_DB,
    ]

    try:
        subprocess.run(cmd, check=True, env={**os.environ, **env} if env else None)
        logger.info(f"Database dumped successfully to {output_path}")
    except subprocess.CalledProcessError as e:
        logger.error(f"pg_dump failed: {e}")
        raise
    except FileNotFoundError:
        logger.error("pg_dump command not found. Make sure PostgreSQL is installed.")
        raise


def restore_database(dump_path: Path, clean: bool = False, if_exists: bool = False) -> None:
    """Restore PostgreSQL database from a dump file.

    Args:
        dump_path: Path to the dump file
        clean: Whether to drop objects before restoring
        if_exists: Whether to ignore errors if table exists

    Raises:
        subprocess.CalledProcessError: If pg_restore fails
        FileNotFoundError: If dump file doesn't exist
    """
    if not dump_path.exists():
        raise FileNotFoundError(f"Dump file not found: {dump_path}")

    logger.info(f"Restoring database from {dump_path}...")

    # Prepare environment
    env = {}
    if Config.POSTGRES_PASSWORD:
        env["PGPASSWORD"] = Config.POSTGRES_PASSWORD

    cmd = [
        "pg_restore",
        f"--host={Config.POSTGRES_HOST}",
        f"--port={Config.POSTGRES_PORT}",
        f"--username={Config.POSTGRES_USER}",
        "--dbname=" + Config.POSTGRES_DB,
        "--no-owner",  # Don't restore object ownership
        "--no-privileges",  # Don't restore privileges
    ]

    if clean:
        cmd.append("--clean")
    if if_exists:
        cmd.append("--if-exists")

    cmd.append(str(dump_path))

    try:
        # Restore database - ignore config parameter warnings
        result = subprocess.run(cmd, capture_output=True, text=True, env={**os.environ, **env} if env else None)

        # Log output for debugging
        if result.stderr:
            logger.debug(f"pg_restore output: {result.stderr}")

        # pg_restore may return non-zero for warnings about config parameters
        # Only fail if there are actual schema/data errors
        if "ERROR" in result.stderr and "transaction_timeout" not in result.stderr:
            # Real error (not just config parameter warning)
            logger.error(f"pg_restore failed: {result.stderr}")
            raise subprocess.CalledProcessError(result.returncode, result.args)

        # Success - whether exit code is 0 or just warnings
        logger.info(f"Database restored successfully from {dump_path}")

    except subprocess.CalledProcessError as e:
        logger.error(f"pg_restore failed: {e}")
        raise
    except FileNotFoundError:
        logger.error("pg_restore command not found. Make sure PostgreSQL is installed.")
        raise
