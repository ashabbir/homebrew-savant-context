"""Database schema creation and initialization."""

import logging

from .client import DatabaseClient

logger = logging.getLogger(__name__)

SCHEMA_SQL = """
-- Repositories table
CREATE TABLE IF NOT EXISTS repos (
    id SERIAL PRIMARY KEY,
    name TEXT NOT NULL UNIQUE,
    path TEXT NOT NULL,
    indexed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Files table
CREATE TABLE IF NOT EXISTS files (
    id SERIAL PRIMARY KEY,
    repo_id INTEGER NOT NULL REFERENCES repos(id) ON DELETE CASCADE,
    rel_path TEXT NOT NULL,
    language TEXT,
    is_memory_bank BOOLEAN DEFAULT FALSE,
    mtime_ns BIGINT,
    indexed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(repo_id, rel_path)
);

-- Chunks table (for full-text search)
CREATE TABLE IF NOT EXISTS chunks (
    id SERIAL PRIMARY KEY,
    file_id INTEGER NOT NULL REFERENCES files(id) ON DELETE CASCADE,
    chunk_index INTEGER NOT NULL,
    content TEXT NOT NULL,
    content_vector tsvector,
    created_at TIMESTAMP DEFAULT NOW()
);

-- Create FTS index on chunks
CREATE INDEX IF NOT EXISTS chunks_fts_idx ON chunks USING GIN(content_vector);

-- Create other useful indexes
CREATE INDEX IF NOT EXISTS files_repo_id_idx ON files(repo_id);
CREATE INDEX IF NOT EXISTS files_language_idx ON files(language);
CREATE INDEX IF NOT EXISTS files_memory_bank_idx ON files(is_memory_bank, repo_id);
CREATE INDEX IF NOT EXISTS chunks_file_id_idx ON chunks(file_id);
CREATE INDEX IF NOT EXISTS repos_name_idx ON repos(name);

-- Create function to automatically update tsvector
CREATE OR REPLACE FUNCTION update_content_vector() RETURNS TRIGGER AS $$
BEGIN
  NEW.content_vector := to_tsvector('english', NEW.content);
  RETURN NEW;
END;
$$ LANGUAGE plpgsql;

-- Create trigger to update content_vector on insert/update
DROP TRIGGER IF EXISTS chunks_content_vector_update ON chunks;
CREATE TRIGGER chunks_content_vector_update
BEFORE INSERT OR UPDATE ON chunks
FOR EACH ROW
EXECUTE FUNCTION update_content_vector();
"""


def init_schema(db_client: DatabaseClient) -> None:
    """Initialize database schema.

    Args:
        db_client: DatabaseClient instance

    Raises:
        Exception: If schema initialization fails
    """
    logger.info("Initializing database schema...")

    try:
        # Execute the entire schema at once to preserve dollar-quoted strings
        try:
            db_client.execute(SCHEMA_SQL)
            logger.debug("Executed complete schema")
        except Exception as e:
            logger.warning(f"Schema execution warning: {e}")

        logger.info("Database schema initialized successfully")
    except Exception as e:
        logger.error(f"Failed to initialize database schema: {e}")
        raise


def drop_schema(db_client: DatabaseClient) -> None:
    """Drop all tables (for testing/cleanup).

    Args:
        db_client: DatabaseClient instance
    """
    logger.warning("Dropping all tables...")

    drop_sql = """
    DROP TABLE IF EXISTS chunks CASCADE;
    DROP TABLE IF EXISTS files CASCADE;
    DROP TABLE IF EXISTS repos CASCADE;
    """

    try:
        statements = [s.strip() for s in drop_sql.split(";") if s.strip()]
        for statement in statements:
            db_client.execute(statement)
        logger.info("All tables dropped")
    except Exception as e:
        logger.error(f"Failed to drop tables: {e}")
        raise
