# Memory Bank Document Distinction Implementation

## Product Requirements Document (PRD)

### Overview
Implement proper distinction between memory bank documents and regular code/documentation in the savant-context system. Memory bank documents are special markdown files stored in designated directories that serve as persistent knowledge bases for AI agents.

### Current State
- Memory bank `.md` files exist in `memory_bank/` directories but are treated like regular markdown
- `memory_search` tool claims to search memory bank but has no actual filtering mechanism
- No database distinction between memory bank and code documentation
- System cannot differentiate between memory bank resources and regular code docs in search results

### Goals
1. **Database Layer**: Add `is_memory_bank` boolean flag to files table
2. **Indexer**: Detect memory bank files based on directory structure (memory/memorybank/bank)
3. **Search Tools**: Filter search results by document type
4. **Resource Management**: Implement dedicated memory bank resource listing/reading

### Success Criteria
- Memory bank files are marked during indexing
- `memory_search` tool filters results to memory bank documents only
- `memory_resources_list` returns memory bank `.md` files with proper metadata
- `memory_resources_read` retrieves full content of specific memory bank files
- `fts_search` can optionally exclude memory bank documents for code-focused search
- Search results include document type indicator

## Implementation Plan

### Phase 1: Database Schema Enhancement
**File**: `savant_context/db/schema.py`

Changes:
- Add `is_memory_bank BOOLEAN DEFAULT FALSE` column to `files` table
- Add index on `(is_memory_bank, repo_id)` for efficient memory bank queries
- Ensure backward compatibility with existing data

```sql
ALTER TABLE files ADD COLUMN is_memory_bank BOOLEAN DEFAULT FALSE;
CREATE INDEX IF NOT EXISTS files_memory_bank_idx ON files(is_memory_bank, repo_id);
```

### Phase 2: Memory Bank Detection Module
**File**: `savant_context/indexer/language.py` (NEW)

Create a language/file detection module that:
- Detects if a file is in a memory bank directory
- Handles variants: `memory`, `memorybank`, `memory_bank`, `memory-bank`, `bank`
- Returns `'memory_bank'` as language for `.md/.mdx/.markdown` files in memory dirs
- Skips non-markdown files in memory directories
- Normalizes path segments by removing dashes/underscores for matching

```python
class MemoryBankDetector:
    MEMORY_DIR_NAMES = {'memory', 'memorybank', 'bank'}
    MARKDOWN_EXTS = {'.md', '.mdx', '.markdown'}

    @staticmethod
    def detect_language(rel_path: str) -> tuple[str, bool]:
        """Returns (language, is_memory_bank)"""
        # Implementation...
```

### Phase 3: Indexer Enhancement
**File**: `savant_context/indexer/indexer.py`

Changes:
- Integrate `MemoryBankDetector` into `detect_language()` method
- Update file record insertion to set `is_memory_bank` flag
- Filter non-markdown files in memory directories during scanning
- Track memory bank file count in statistics

### Phase 4: Search Tools Update
**File**: `savant_context/mcp/tools.py`

Changes:
- **fts_search**: Add optional `exclude_memory_bank` parameter
- **memory_search**: Add `WHERE f.is_memory_bank = TRUE` to filter
- **memory_resources_list**: Query only memory bank files with full metadata
- **memory_resources_read**: Read specific memory bank resource by URI
- All tools: Include `is_memory_bank` in result set

### Phase 5: Resource Management Tools
**File**: `savant_context/mcp/tools.py`

New implementations:
- **memory_resources_list**: List all memory bank files as resources
  - Return: `[{uri, repo, path, filename, size, created_at}, ...]`
- **memory_resources_read**: Read memory bank file by URI
  - Return: `{uri, repo, path, content, size, created_at}`

### Phase 6: Testing & Migration
- Test memory bank detection with various directory names
- Verify backward compatibility with existing indexed repos
- Performance test on large codebases with multiple memory banks
- Documentation updates

## Database Schema Changes

### NEW files table structure:
```sql
CREATE TABLE IF NOT EXISTS files (
    id SERIAL PRIMARY KEY,
    repo_id INTEGER NOT NULL REFERENCES repos(id) ON DELETE CASCADE,
    rel_path TEXT NOT NULL,
    language TEXT,
    is_memory_bank BOOLEAN DEFAULT FALSE,
    mtime_ns BIGINT,
    indexed_at TIMESTAMP,
    created_at TIMESTAMP DEFAULT NOW(),
    UNIQUE(repo_id, rel_path)
);

CREATE INDEX IF NOT EXISTS files_memory_bank_idx ON files(is_memory_bank, repo_id);
```

## API Changes

### Updated Tools

#### memory_search (EXISTING - MODIFIED)
```json
{
  "query": "search_term",
  "repo": "optional_repo_name",
  "limit": 20
}
```
**New behavior**: Filters to `is_memory_bank = TRUE` only

#### memory_resources_list (EXISTING - MODIFIED)
```json
{
  "repo": "optional_repo_name"
}
```
**Response**:
```json
{
  "result_count": 5,
  "resources": [
    {
      "uri": "repo:memory_bank/architecture.md",
      "repo": "my-repo",
      "path": "memory_bank/architecture.md",
      "filename": "architecture.md",
      "is_memory_bank": true
    }
  ]
}
```

#### memory_resources_read (EXISTING - MODIFIED)
```json
{
  "uri": "repo:memory_bank/architecture.md"
}
```
**Response**:
```json
{
  "uri": "repo:memory_bank/architecture.md",
  "repo": "my-repo",
  "path": "memory_bank/architecture.md",
  "content": "# Architecture\n...",
  "size": 1024,
  "created_at": "2025-12-19T00:00:00Z"
}
```

#### fts_search (EXISTING - MODIFIED)
**New optional parameter**: `exclude_memory_bank: boolean` (default: false)
- When true, excludes `is_memory_bank = TRUE` from results
- Results now include `is_memory_bank` field

## File Types & Examples

### Memory Bank Detection Examples

✅ **DETECTED AS MEMORY BANK**:
- `memory_bank/architecture.md`
- `memory/design.md`
- `memorybank/api.md`
- `memory-bank/notes.md`
- `MEMORY_BANK/guide.mdx`
- `bank/readme.md`

❌ **NOT MEMORY BANK**:
- `memory_bank/diagram.png` (not markdown)
- `memory_bank/config.json` (not markdown)
- `memory/notes.txt` (not markdown)
- `docs/memory.md` (not in memory dir)
- `README.md` (not in memory dir)

## Implementation Order

1. **Step 1**: Create `MemoryBankDetector` class
2. **Step 2**: Update database schema with migration SQL
3. **Step 3**: Integrate detector into `Indexer.detect_language()`
4. **Step 4**: Update `index_repository()` to set `is_memory_bank` flag
5. **Step 5**: Implement `memory_resources_list()` tool
6. **Step 6**: Implement `memory_resources_read()` tool
7. **Step 7**: Update `memory_search()` to filter by `is_memory_bank`
8. **Step 8**: Update `fts_search()` with optional exclusion
9. **Step 9**: Add comprehensive tests
10. **Step 10**: Update CLI and documentation

## Risk Assessment

### Low Risk
- Adding new column to files table (default to FALSE)
- New tool implementations (isolated)
- Memory bank detection logic (pure function)

### Medium Risk
- Index migration for existing repos (need careful handling)
- Backward compatibility with existing indexes

### Mitigation
- Add migration helper to re-index repos with new logic
- Provide `savant-context db migrate-memory-bank` command
- Maintain fallback for repos without is_memory_bank flag

## Performance Considerations

- **Query optimization**: New index on `(is_memory_bank, repo_id)` speeds memory bank queries
- **Indexing overhead**: Minimal (one boolean flag assignment per file)
- **Storage**: ~1 byte per file (boolean storage overhead negligible)

## Timeline Estimate

- Phase 1-2 (Schema + Detector): 30 mins
- Phase 3 (Indexer integration): 30 mins
- Phase 4-5 (Tools update): 45 mins
- Phase 6 (Testing + docs): 30 mins
- **Total: ~2.5 hours**

---

## Definition of Done

- [ ] MemoryBankDetector class implemented and tested
- [ ] Database schema updated with migration support
- [ ] Indexer detects and flags memory bank files
- [ ] memory_search filters to memory bank only
- [ ] memory_resources_list returns memory bank metadata
- [ ] memory_resources_read retrieves memory bank content
- [ ] fts_search can exclude memory bank documents
- [ ] All search results include is_memory_bank field
- [ ] Backward compatibility verified
- [ ] Documentation updated
- [ ] Integration tests passing
