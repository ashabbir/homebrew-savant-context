"""MCP tool implementations."""

import logging
from typing import Any, Dict, List, Optional

from ..db.client import DatabaseClient
from ..indexer.indexer import Indexer

logger = logging.getLogger(__name__)


class ToolHandler:
    """Handles MCP tool calls."""

    def __init__(self, db_client: DatabaseClient):
        """Initialize tool handler.

        Args:
            db_client: DatabaseClient instance
        """
        self.db = db_client
        self.indexer = Indexer(db_client)

    def search_sync(
        self, query: str, repo: Optional[str] = None, limit: int = 10
    ) -> Dict[str, Any]:
        """Full-text search across indexed code.

        Args:
            query: Search query
            repo: Optional repository filter
            limit: Maximum results

        Returns:
            Search results
        """
        try:
            # Build SQL query
            sql = """
                SELECT
                    r.name as repo,
                    f.rel_path,
                    f.language,
                    c.chunk_index,
                    c.content,
                    ts_rank(c.content_vector, plainto_tsquery('english', %s)) as rank
                FROM chunks c
                JOIN files f ON c.file_id = f.id
                JOIN repos r ON f.repo_id = r.id
                WHERE c.content_vector @@ plainto_tsquery('english', %s)
            """
            params: List[Any] = [query, query]

            if repo:
                sql += " AND r.name = %s"
                params.append(repo)

            sql += " ORDER BY rank DESC LIMIT %s"
            params.append(limit)

            results = self.db.fetch_all(sql, tuple(params))

            return {
                "query": query,
                "repo_filter": repo,
                "result_count": len(results),
                "results": results,
            }
        except Exception as e:
            logger.error(f"Search failed: {e}")
            return {"error": str(e), "query": query}

    def list_repos_sync(self) -> Dict[str, Any]:
        """List all indexed repositories.

        Returns:
            List of repositories
        """
        try:
            repos = self.db.fetch_all(
                """
                SELECT
                    name,
                    path,
                    indexed_at,
                    (SELECT COUNT(*) FROM files WHERE repo_id = repos.id) as file_count,
                    (SELECT COUNT(*) FROM chunks WHERE file_id IN
                        (SELECT id FROM files WHERE repo_id = repos.id)) as chunk_count
                FROM repos
                ORDER BY name
                """
            )

            return {"repo_count": len(repos), "repos": repos}
        except Exception as e:
            logger.error(f"List repos failed: {e}")
            return {"error": str(e)}

    def repo_stats_sync(self, repo_name: Optional[str] = None) -> Dict[str, Any]:
        """Get repository statistics.

        Args:
            repo_name: Optional specific repository

        Returns:
            Repository statistics
        """
        try:
            stats = self.indexer.get_repository_stats()

            if repo_name:
                stats = [s for s in stats if s["name"] == repo_name]

            return {"stats": stats, "count": len(stats)}
        except Exception as e:
            logger.error(f"Repo stats failed: {e}")
            return {"error": str(e)}

    def index_repo_sync(self, path: str, name: Optional[str] = None) -> Dict[str, Any]:
        """Trigger repository indexing.

        Args:
            path: Path to repository
            name: Optional repository name

        Returns:
            Indexing results
        """
        try:
            result = self.indexer.index_repository(path, repo_name=name, verbose=True)
            return result
        except Exception as e:
            logger.error(f"Index repo failed: {e}")
            return {"error": str(e), "path": path}

    def delete_repo_sync(self, name: str) -> Dict[str, Any]:
        """Delete a repository from index.

        Args:
            name: Repository name

        Returns:
            Deletion result
        """
        try:
            result = self.indexer.delete_repository(name)
            return result
        except Exception as e:
            logger.error(f"Delete repo failed: {e}")
            return {"error": str(e), "name": name}


def get_tool_definitions() -> List[Dict[str, Any]]:
    """Get MCP tool definitions.

    Returns:
        List of tool definitions
    """
    return [
        {
            "name": "search",
            "description": "Full-text search across indexed code repositories",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "Search query (e.g., 'function def' or 'error handling')",
                    },
                    "repo": {
                        "type": "string",
                        "description": "Optional repository name to filter results",
                    },
                    "limit": {
                        "type": "number",
                        "description": "Maximum number of results (default: 10)",
                        "default": 10,
                    },
                },
                "required": ["query"],
            },
        },
        {
            "name": "list_repos",
            "description": "List all indexed repositories with file and chunk counts",
            "inputSchema": {"type": "object", "properties": {}, "required": []},
        },
        {
            "name": "repo_stats",
            "description": "Get statistics for indexed repositories",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "repo_name": {
                        "type": "string",
                        "description": "Optional specific repository name",
                    }
                },
                "required": [],
            },
        },
        {
            "name": "index_repo",
            "description": "Index a code repository",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "path": {"type": "string", "description": "Path to repository"},
                    "name": {
                        "type": "string",
                        "description": "Optional repository name (default: folder name)",
                    },
                },
                "required": ["path"],
            },
        },
        {
            "name": "delete_repo",
            "description": "Remove a repository from the index",
            "inputSchema": {
                "type": "object",
                "properties": {
                    "name": {"type": "string", "description": "Repository name to delete"}
                },
                "required": ["name"],
            },
        },
    ]
