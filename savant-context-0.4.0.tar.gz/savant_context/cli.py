"""CLI for savant-context."""

import logging
from pathlib import Path
from typing import Optional

import click

from . import __version__
from .config import Config
from .db import DatabaseClient, init_schema
from .db.operations import dump_database, restore_database, create_database
from .indexer import Indexer
from .mcp.server import MCPServer

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)


def get_db_client() -> DatabaseClient:
    """Get a connected database client."""
    client = DatabaseClient()
    try:
        client.connect()
    except Exception as e:
        click.echo(f"Error: Failed to connect to database: {e}", err=True)
        raise click.Abort()
    return client


@click.group()
@click.version_option(version=__version__)
def main() -> None:
    """Savant Context - Code indexer and MCP server."""
    pass


@main.command()
def run() -> None:
    """Start the MCP server."""
    click.echo("Starting Savant Context MCP server...")

    db_client = get_db_client()

    try:
        # Verify schema exists
        if not db_client.table_exists("repos"):
            click.echo("Database schema not initialized. Run 'db:setup' first.", err=True)
            db_client.close()
            raise click.Abort()

        # Create and run MCP server
        mcp = MCPServer(db_client)
        click.echo("MCP server running. Press Ctrl+C to stop.")

        try:
            mcp.run()
        except KeyboardInterrupt:
            click.echo("\nShutting down...")
        finally:
            db_client.close()

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@main.group()
def db() -> None:
    """Database management commands."""
    pass


@db.command(name="setup")
def db_setup() -> None:
    """Initialize the database and create schema."""
    click.echo("Setting up database...")

    try:
        # Create database if it doesn't exist
        click.echo("Creating database if needed...")
        create_database()
        click.echo("✓ Database ready")

        # Connect and initialize schema
        db_client = get_db_client()
        init_schema(db_client)
        click.echo("✓ Database schema initialized successfully")
        db_client.close()

    except Exception as e:
        click.echo(f"Error: Failed to initialize database: {e}", err=True)
        raise click.Abort()


@db.command(name="dump")
@click.argument("output_path", type=click.Path())
def db_dump(output_path: str) -> None:
    """Dump the database to a file.

    OUTPUT_PATH: Path where to save the dump file
    """
    output_file = Path(output_path)

    if output_file.exists():
        if not click.confirm(f"File {output_path} exists. Overwrite?"):
            click.echo("Aborted")
            return

    click.echo(f"Dumping database to {output_path}...")

    try:
        dump_database(output_file)
        click.echo(f"✓ Database dumped successfully to {output_path}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="restore")
@click.argument("dump_path", type=click.Path(exists=True))
@click.option("--clean", is_flag=True, help="Drop objects before restoring")
def db_restore(dump_path: str, clean: bool) -> None:
    """Restore the database from a dump file.

    DUMP_PATH: Path to the dump file
    """
    if not click.confirm(f"Restore database from {dump_path}? This will replace existing data."):
        click.echo("Aborted")
        return

    click.echo(f"Restoring database from {dump_path}...")

    try:
        # Create database if it doesn't exist
        click.echo("Creating database if needed...")
        create_database()
        click.echo("✓ Database ready")

        # Restore from dump
        restore_database(Path(dump_path), clean=clean)
        click.echo(f"✓ Database restored successfully from {dump_path}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@db.command(name="destroy")
def db_destroy() -> None:
    """Destroy the database completely.

    WARNING: This permanently deletes all indexed data.
    """
    if not click.confirm("⚠️  This will permanently delete ALL indexed data. Are you sure?"):
        click.echo("Aborted")
        return

    if not click.confirm("Type 'destroy' to confirm permanent deletion"):
        click.echo("Aborted")
        return

    click.echo("Destroying database...")

    try:
        db_client = get_db_client()

        # Drop all tables
        db_client.execute("DROP TABLE IF EXISTS chunks CASCADE")
        db_client.execute("DROP TABLE IF EXISTS files CASCADE")
        db_client.execute("DROP TABLE IF EXISTS repos CASCADE")

        click.echo("✓ Database destroyed successfully")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()


@main.command()
def status() -> None:
    """Show status of indexed repositories."""
    db_client = get_db_client()

    try:
        # Check if schema exists
        if not db_client.table_exists("repos"):
            click.echo("No repositories indexed yet. Run 'index:repo' to start indexing.")
            return

        # Get repository stats
        stats = db_client.fetch_all(
            """
            SELECT
                r.name,
                r.indexed_at,
                COUNT(DISTINCT f.id) as file_count,
                COUNT(DISTINCT c.id) as chunk_count
            FROM repos r
            LEFT JOIN files f ON r.id = f.repo_id
            LEFT JOIN chunks c ON f.id = c.file_id
            GROUP BY r.id, r.name, r.indexed_at
            ORDER BY r.name
            """
        )

        if not stats:
            click.echo("No repositories indexed yet. Run 'index:repo' to start indexing.")
            return

        # Display table
        click.echo("\nRepository Status")
        click.echo("─" * 70)
        click.echo(f"{'Name':<25} {'Files':>10} {'Chunks':>10} {'Last Indexed':<25}")
        click.echo("─" * 70)

        total_files = 0
        total_chunks = 0

        for repo in stats:
            files = repo["file_count"] or 0
            chunks = repo["chunk_count"] or 0
            indexed_at = repo["indexed_at"] or "Never"

            total_files += files
            total_chunks += chunks

            click.echo(
                f"{repo['name']:<25} {files:>10,} {chunks:>10,} {str(indexed_at):<25}"
            )

        click.echo("─" * 70)
        click.echo(
            f"{'Total':<25} {total_files:>10,} {total_chunks:>10,} "
            f"{len(stats)} repositories"
        )
        click.echo()

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


@main.group()
def index() -> None:
    """Repository indexing commands."""
    pass


@index.command(name="repo")
@click.argument("path", type=click.Path(exists=True, file_okay=False, dir_okay=True), required=False, default=".")
@click.option("--name", default=None, help="Repository name (default: folder name)")
def index_repo(path: str, name: Optional[str]) -> None:
    """Index a repository.

    PATH: Path to the repository to index (default: current directory)
    """
    repo_path = Path(path).resolve()
    repo_name = name or repo_path.name

    click.echo(f"Indexing repository: {repo_name}")
    click.echo(f"Path: {repo_path}")

    db_client = get_db_client()

    try:
        # Check if schema exists
        if not db_client.table_exists("repos"):
            click.echo("Database schema not initialized. Run 'db:setup' first.", err=True)
            raise click.Abort()

        indexer = Indexer(db_client)
        result = indexer.index_repository(repo_path, repo_name=repo_name, verbose=True)

        click.echo("\n✓ Indexing complete")
        click.echo(f"  Files indexed: {result['files_indexed']}")
        click.echo(f"  Chunks indexed: {result['chunks_indexed']}")
        if result["errors"]:
            click.echo(f"  Errors: {result['errors']}")

    except Exception as e:
        click.echo(f"Error: {e}", err=True)
        raise click.Abort()
    finally:
        db_client.close()


if __name__ == "__main__":
    main()
